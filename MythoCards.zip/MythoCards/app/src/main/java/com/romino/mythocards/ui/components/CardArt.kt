package com.romino.mythocards.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import com.romino.mythocards.model.CardSymbol
import com.romino.mythocards.model.Rarity
import kotlin.math.cos
import kotlin.math.sin

/**
 * Génère un visuel unique par carte à partir de sa forme (symbole) et de sa rareté,
 * sans dépendre d'images bitmap : chaque carte a un rendu vectoriel distinct.
 */
@androidx.compose.runtime.Composable
fun CardArt(symbol: CardSymbol, rarity: Rarity, seed: Int, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.aspectRatio(1f).fillMaxSize()) {
        val w = size.width
        val h = size.height
        val rnd = kotlin.random.Random(seed)

        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(rarity.secondaryColor, rarity.primaryColor.copy(alpha = 0.85f)),
                center = Offset(w / 2f, h * 0.35f),
                radius = w
            )
        )

        // Éclats de fond selon la rareté (plus il y en a, plus la carte est rare)
        val sparkCount = when (rarity) {
            Rarity.COMMUN -> 0
            Rarity.RARE -> 4
            Rarity.EPIQUE -> 8
            Rarity.LEGENDAIRE -> 14
            Rarity.MYTHIQUE -> 22
        }
        repeat(sparkCount) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            drawCircle(color = rarity.glow.copy(alpha = 0.5f), radius = w * 0.01f + rnd.nextFloat() * w * 0.015f, center = Offset(x, y))
        }

        val center = Offset(w / 2f, h * 0.52f)
        val baseColor = rarity.glow
        val strokeColor = Color.White.copy(alpha = 0.9f)

        when (symbol) {
            CardSymbol.DRAGON -> drawDragon(center, w, baseColor, strokeColor)
            CardSymbol.PHOENIX -> drawPhoenix(center, w, baseColor, strokeColor)
            CardSymbol.GOLEM -> drawGolem(center, w, baseColor, strokeColor)
            CardSymbol.SPECTRE -> drawSpectre(center, w, baseColor, strokeColor)
            CardSymbol.KRAKEN -> drawKraken(center, w, baseColor, strokeColor)
            CardSymbol.LOUP -> drawLoup(center, w, baseColor, strokeColor)
            CardSymbol.SERPENT -> drawSerpent(center, w, baseColor, strokeColor)
            CardSymbol.TITAN -> drawGolem(center, w, baseColor, strokeColor)
            CardSymbol.DEMON -> drawDemon(center, w, baseColor, strokeColor)
            CardSymbol.ANGE -> drawAnge(center, w, baseColor, strokeColor)
            CardSymbol.HYDRE -> drawHydre(center, w, baseColor, strokeColor)
            CardSymbol.GRIFFON -> drawGriffon(center, w, baseColor, strokeColor)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDragon(c: Offset, w: Float, fill: Color, stroke: Color) {
    val r = w * 0.22f
    drawCircle(fill, r, c)
    val path = Path().apply {
        moveTo(c.x - r * 1.6f, c.y)
        lineTo(c.x - r * 0.6f, c.y - r * 0.9f)
        lineTo(c.x - r * 0.2f, c.y - r * 0.2f)
        close()
        moveTo(c.x + r * 1.6f, c.y)
        lineTo(c.x + r * 0.6f, c.y - r * 0.9f)
        lineTo(c.x + r * 0.2f, c.y - r * 0.2f)
        close()
    }
    drawPath(path, fill)
    drawPath(path, stroke, style = Stroke(width = w * 0.01f))
    drawCircle(stroke, r, c, style = Stroke(width = w * 0.015f))
    drawCircle(Color.Yellow, r * 0.15f, Offset(c.x - r * 0.35f, c.y - r * 0.1f))
    drawCircle(Color.Yellow, r * 0.15f, Offset(c.x + r * 0.35f, c.y - r * 0.1f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawPhoenix(c: Offset, w: Float, fill: Color, stroke: Color) {
    val r = w * 0.24f
    val path = Path()
    for (i in 0 until 7) {
        val angle = Math.PI * (i / 6.0) - Math.PI / 2
        val x = c.x + (r * 1.4f * cos(angle)).toFloat()
        val y = c.y + (r * 1.4f * sin(angle)).toFloat()
        if (i == 0) path.moveTo(c.x, c.y) else path.lineTo(x, y)
        path.lineTo(c.x, c.y)
    }
    drawPath(path, fill.copy(alpha = 0.8f))
    drawCircle(fill, r * 0.5f, c)
    drawCircle(stroke, r * 0.5f, c, style = Stroke(width = w * 0.012f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGolem(c: Offset, w: Float, fill: Color, stroke: Color) {
    val s = w * 0.34f
    drawRoundRect(
        color = fill,
        topLeft = Offset(c.x - s / 2, c.y - s / 2),
        size = androidx.compose.ui.geometry.Size(s, s),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.03f)
    )
    drawRoundRect(
        color = stroke,
        topLeft = Offset(c.x - s / 2, c.y - s / 2),
        size = androidx.compose.ui.geometry.Size(s, s),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.03f),
        style = Stroke(width = w * 0.012f)
    )
    drawCircle(Color.Yellow, s * 0.08f, Offset(c.x - s * 0.18f, c.y))
    drawCircle(Color.Yellow, s * 0.08f, Offset(c.x + s * 0.18f, c.y))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSpectre(c: Offset, w: Float, fill: Color, stroke: Color) {
    val r = w * 0.22f
    val path = Path().apply {
        moveTo(c.x - r, c.y)
        cubicTo(c.x - r, c.y - r * 1.6f, c.x + r, c.y - r * 1.6f, c.x + r, c.y)
        lineTo(c.x + r, c.y + r * 0.9f)
        lineTo(c.x + r * 0.5f, c.y + r * 0.5f)
        lineTo(c.x, c.y + r * 0.9f)
        lineTo(c.x - r * 0.5f, c.y + r * 0.5f)
        close()
    }
    drawPath(path, fill.copy(alpha = 0.75f))
    drawPath(path, stroke, style = Stroke(width = w * 0.01f))
    drawCircle(Color.Black, r * 0.12f, Offset(c.x - r * 0.3f, c.y - r * 0.2f))
    drawCircle(Color.Black, r * 0.12f, Offset(c.x + r * 0.3f, c.y - r * 0.2f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawKraken(c: Offset, w: Float, fill: Color, stroke: Color) {
    val r = w * 0.18f
    drawCircle(fill, r, c)
    for (i in 0 until 6) {
        val angle = Math.PI * 2 * i / 6
        val path = Path().apply {
            moveTo(c.x, c.y)
            val midX = c.x + (r * 2.2f * cos(angle)).toFloat()
            val midY = c.y + (r * 2.2f * sin(angle)).toFloat()
            quadraticTo(
                c.x + (r * 1.2f * cos(angle + 0.3)).toFloat(),
                c.y + (r * 1.2f * sin(angle + 0.3)).toFloat(),
                midX, midY
            )
        }
        drawPath(path, stroke, style = Stroke(width = w * 0.02f, cap = StrokeCap.Round))
    }
    drawCircle(Color.White, r * 0.15f, Offset(c.x - r * 0.3f, c.y - r * 0.2f))
    drawCircle(Color.White, r * 0.15f, Offset(c.x + r * 0.3f, c.y - r * 0.2f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawLoup(c: Offset, w: Float, fill: Color, stroke: Color) {
    val r = w * 0.2f
    val path = Path().apply {
        moveTo(c.x, c.y - r * 1.2f)
        lineTo(c.x - r, c.y + r * 0.6f)
        lineTo(c.x - r * 0.4f, c.y + r * 0.3f)
        lineTo(c.x, c.y + r)
        lineTo(c.x + r * 0.4f, c.y + r * 0.3f)
        lineTo(c.x + r, c.y + r * 0.6f)
        close()
    }
    drawPath(path, fill)
    drawPath(path, stroke, style = Stroke(width = w * 0.01f))
    drawCircle(Color.Yellow, r * 0.1f, Offset(c.x - r * 0.25f, c.y - r * 0.1f))
    drawCircle(Color.Yellow, r * 0.1f, Offset(c.x + r * 0.25f, c.y - r * 0.1f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSerpent(c: Offset, w: Float, fill: Color, stroke: Color) {
    val path = Path().apply {
        moveTo(c.x - w * 0.25f, c.y + w * 0.15f)
        cubicTo(
            c.x - w * 0.1f, c.y - w * 0.15f,
            c.x + w * 0.1f, c.y + w * 0.2f,
            c.x + w * 0.25f, c.y - w * 0.1f
        )
    }
    drawPath(path, stroke, style = Stroke(width = w * 0.05f, cap = StrokeCap.Round))
    drawCircle(fill, w * 0.06f, Offset(c.x + w * 0.25f, c.y - w * 0.1f))
    drawCircle(Color.Yellow, w * 0.015f, Offset(c.x + w * 0.27f, c.y - w * 0.11f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDemon(c: Offset, w: Float, fill: Color, stroke: Color) {
    val r = w * 0.2f
    drawCircle(fill, r, c)
    val hornPath = Path().apply {
        moveTo(c.x - r * 0.6f, c.y - r * 0.7f)
        lineTo(c.x - r * 1.2f, c.y - r * 1.5f)
        lineTo(c.x - r * 0.3f, c.y - r * 0.9f)
        close()
        moveTo(c.x + r * 0.6f, c.y - r * 0.7f)
        lineTo(c.x + r * 1.2f, c.y - r * 1.5f)
        lineTo(c.x + r * 0.3f, c.y - r * 0.9f)
        close()
    }
    drawPath(hornPath, stroke)
    drawCircle(Color.Red, r * 0.12f, Offset(c.x - r * 0.3f, c.y - r * 0.1f))
    drawCircle(Color.Red, r * 0.12f, Offset(c.x + r * 0.3f, c.y - r * 0.1f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAnge(c: Offset, w: Float, fill: Color, stroke: Color) {
    val r = w * 0.2f
    drawCircle(Color.White.copy(alpha = 0.9f), r * 0.9f, Offset(c.x, c.y - r * 0.2f))
    val wingPath = Path().apply {
        moveTo(c.x, c.y)
        cubicTo(c.x - r * 2f, c.y - r * 1.3f, c.x - r * 2f, c.y + r * 0.8f, c.x - r * 0.3f, c.y + r * 0.3f)
        close()
        moveTo(c.x, c.y)
        cubicTo(c.x + r * 2f, c.y - r * 1.3f, c.x + r * 2f, c.y + r * 0.8f, c.x + r * 0.3f, c.y + r * 0.3f)
        close()
    }
    drawPath(wingPath, fill.copy(alpha = 0.85f))
    drawPath(wingPath, stroke, style = Stroke(width = w * 0.008f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawHydre(c: Offset, w: Float, fill: Color, stroke: Color) {
    val r = w * 0.14f
    val offsets = listOf(-1.3f, 0f, 1.3f)
    for (dx in offsets) {
        drawCircle(fill, r, Offset(c.x + dx * r, c.y - if (dx == 0f) r * 0.6f else 0f))
        drawCircle(stroke, r, Offset(c.x + dx * r, c.y - if (dx == 0f) r * 0.6f else 0f), style = Stroke(width = w * 0.008f))
        drawCircle(Color.Yellow, r * 0.15f, Offset(c.x + dx * r - r * 0.25f, c.y - if (dx == 0f) r * 0.6f else 0f))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGriffon(c: Offset, w: Float, fill: Color, stroke: Color) {
    val r = w * 0.2f
    drawCircle(fill, r * 0.8f, c)
    val wingPath = Path().apply {
        moveTo(c.x, c.y)
        lineTo(c.x - r * 1.8f, c.y - r * 0.6f)
        lineTo(c.x - r * 1.4f, c.y + r * 0.2f)
        lineTo(c.x - r * 0.6f, c.y - r * 0.1f)
        close()
        moveTo(c.x, c.y)
        lineTo(c.x + r * 1.8f, c.y - r * 0.6f)
        lineTo(c.x + r * 1.4f, c.y + r * 0.2f)
        lineTo(c.x + r * 0.6f, c.y - r * 0.1f)
        close()
    }
    drawPath(wingPath, stroke)
    val beak = Path().apply {
        moveTo(c.x - r * 0.15f, c.y - r * 0.6f)
        lineTo(c.x + r * 0.15f, c.y - r * 0.6f)
        lineTo(c.x, c.y - r * 1.1f)
        close()
    }
    drawPath(beak, Color(0xFFFFC300))
}
