package com.romino.mythocards.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.romino.mythocards.data.BattleController
import com.romino.mythocards.data.CardDatabase
import com.romino.mythocards.data.GameRepository
import com.romino.mythocards.model.BoardUnit
import com.romino.mythocards.model.Turn
import com.romino.mythocards.ui.components.CardArt

@Composable
fun BattleScreen(onExit: () -> Unit) {
    val playerDeck = remember {
        val owned = GameRepository.ownedCardIds().mapNotNull { CardDatabase.byId(it) }
        if (owned.size < 8) owned + CardDatabase.cardsOfRarity(com.romino.mythocards.model.Rarity.COMMUN) else owned
    }
    val controller = remember { BattleController(playerDeck) }
    var selectedSlot by remember { mutableStateOf<Int?>(null) }
    var rewardClaimed by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF3C096C), Color(0xFF0D1B2A))))
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            // Barre ennemie
            HealthBar(label = "Adversaire", health = controller.enemyHealth, max = 30, color = Color(0xFFE63946))
            BoardRow(
                units = controller.enemyBoard,
                isEnemy = true,
                selectable = selectedSlot != null,
                onSlotClick = { slot ->
                    val src = selectedSlot
                    if (src != null) {
                        controller.attack(src, slot)
                        selectedSlot = null
                    }
                }
            )

            Spacer(Modifier.height(8.dp))
            Divider(color = Color(0xFF8D99AE).copy(alpha = 0.3f))
            Spacer(Modifier.height(8.dp))

            // Plateau joueur
            BoardRow(
                units = controller.playerBoard,
                isEnemy = false,
                selectable = false,
                highlightSlot = selectedSlot,
                onSlotClick = { slot ->
                    val unit = controller.playerBoard.getOrNull(slot)
                    if (unit != null && !unit.hasAttacked && controller.turn == Turn.JOUEUR) {
                        selectedSlot = if (selectedSlot == slot) null else slot
                    }
                }
            )
            if (selectedSlot != null) {
                Text(
                    "Choisissez une cible ennemie, ou attaquez directement ⬇",
                    color = Color(0xFFFFD873),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Button(
                    onClick = { controller.attack(selectedSlot!!, null); selectedSlot = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE63946)),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) { Text("Attaque directe au visage 👊") }
            }

            HealthBar(label = "Vous", health = controller.playerHealth, max = 30, color = Color(0xFF52B788))

            Spacer(Modifier.height(6.dp))
            Text(
                "Mana : ${controller.mana} / ${controller.maxMana}",
                color = Color(0xFF4CC9F0),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )

            // Main du joueur
            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(controller.hand.size) { i ->
                    val card = controller.hand[i]
                    val playable = controller.canPlay(card) && controller.turn == Turn.JOUEUR
                    Box(
                        modifier = Modifier
                            .size(80.dp, 110.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (playable) card.rarity.secondaryColor else Color(0xFF1B263B))
                            .border(2.dp, card.rarity.glow, RoundedCornerShape(10.dp))
                            .clickable(enabled = playable) { controller.playCard(i) }
                            .padding(4.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CardArt(card.symbol, card.rarity, card.id.hashCode(), Modifier.size(50.dp))
                            Text(card.name, color = Color.White, fontSize = 9.sp, maxLines = 2)
                            Text("Coût ${card.cost} · ⚔${card.attack}", color = Color(0xFFFFD873), fontSize = 9.sp)
                        }
                    }
                }
            }

            Button(
                onClick = { controller.endTurn(); selectedSlot = null },
                enabled = controller.turn == Turn.JOUEUR && !controller.gameOver,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB703)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    if (controller.turn == Turn.JOUEUR) "Terminer le tour" else "Tour de l'adversaire...",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(6.dp))
            Text(controller.log.firstOrNull() ?: "", color = Color(0xFF8D99AE), fontSize = 11.sp, maxLines = 2)
        }

        if (controller.gameOver) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color(0xDD000814)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (controller.playerWon) "🏆 Victoire !" else "💀 Défaite",
                        color = if (controller.playerWon) Color(0xFFFFD873) else Color(0xFFE63946),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    if (controller.playerWon && !rewardClaimed) {
                        GameRepository.earnGold(controller.goldReward)
                        rewardClaimed = true
                    }
                    if (controller.playerWon) {
                        Text("+ ${controller.goldReward} 💰", color = Color(0xFFFFD873), fontSize = 18.sp)
                    }
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = onExit, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CC9F0))) {
                        Text("Retour", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun HealthBar(label: String, health: Int, max: Int, color: Color) {
    Column {
        Text("$label — $health / $max PV", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        LinearProgressIndicator(
            progress = { (health.coerceAtLeast(0).toFloat() / max) },
            color = color,
            trackColor = Color(0xFF1B263B),
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
        )
    }
}

@Composable
private fun BoardRow(
    units: List<BoardUnit?>,
    isEnemy: Boolean,
    selectable: Boolean,
    highlightSlot: Int? = null,
    onSlotClick: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        units.forEachIndexed { i, unit ->
            Box(
                modifier = Modifier
                    .size(72.dp, 96.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (unit != null) unit.template.rarity.secondaryColor else Color(0xFF1B263B).copy(alpha = 0.5f))
                    .border(
                        2.dp,
                        if (highlightSlot == i) Color(0xFFFFD873) else (unit?.template?.rarity?.glow ?: Color.Transparent),
                        RoundedCornerShape(10.dp)
                    )
                    .clickable(enabled = unit != null && (selectable || !isEnemy)) { onSlotClick(i) }
                    .padding(4.dp)
            ) {
                if (unit != null) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CardArt(unit.template.symbol, unit.template.rarity, unit.template.id.hashCode(), Modifier.size(40.dp))
                        Text(unit.template.name, color = Color.White, fontSize = 8.sp, maxLines = 1)
                        Text("⚔${unit.template.attack} ❤${unit.currentHealth}", color = Color(0xFFFFD873), fontSize = 9.sp)
                    }
                }
            }
        }
    }
}
