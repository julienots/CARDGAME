package com.romino.mythocards.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.romino.mythocards.data.GameRepository

@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0D1B2A), Color(0xFF1B263B)))
            )
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("MythoCards", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
        Text("Collectionnez. Ouvrez. Combattez.", color = Color(0xFF8D99AE), fontSize = 14.sp)

        Spacer(Modifier.height(24.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF2B2D42))
                .padding(horizontal = 24.dp, vertical = 14.dp)
        ) {
            Text("💰 ${GameRepository.gold} pièces d'or", color = Color(0xFFFFD873), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(16.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF2B2D42))
                .padding(horizontal = 24.dp, vertical = 10.dp)
        ) {
            Text("📖 ${GameRepository.collection.size} cartes uniques collectées sur ${com.romino.mythocards.data.CardDatabase.allCards.size}", color = Color.White, fontSize = 13.sp)
        }

        Spacer(Modifier.height(40.dp))
        HomeButton("🎁  Boutique & Boosters", Color(0xFFFFB703)) { onNavigate("boutique") }
        Spacer(Modifier.height(14.dp))
        HomeButton("🃏  Ma Collection", Color(0xFF4CC9F0)) { onNavigate("collection") }
        Spacer(Modifier.height(14.dp))
        HomeButton("⚔️  Combattre", Color(0xFFE63946)) { onNavigate("combat") }
    }
}

@Composable
private fun HomeButton(text: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = color),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().height(56.dp)
    ) {
        Text(text, color = Color(0xFF0D1B2A), fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}
