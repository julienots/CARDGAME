package com.romino.mythocards.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.romino.mythocards.model.BoardUnit
import com.romino.mythocards.model.CardTemplate
import com.romino.mythocards.model.Turn

/**
 * Moteur de combat tour par tour façon jeu de cartes à collectionner :
 * chaque joueur pose des créatures sur un plateau de 3 emplacements et
 * attaque soit une créature adverse, soit directement le point de vie adverse.
 */
class BattleController(playerDeck: List<CardTemplate>) {

    var playerHealth by mutableIntStateOf(30)
    var enemyHealth by mutableIntStateOf(30)
    var mana by mutableIntStateOf(1)
    var maxMana by mutableIntStateOf(1)
    var turn by mutableStateOf(Turn.JOUEUR)
    var turnNumber by mutableIntStateOf(1)
    var gameOver by mutableStateOf(false)
    var playerWon by mutableStateOf(false)
    var goldReward by mutableIntStateOf(0)

    val hand = mutableStateListOf<CardTemplate>()
    val playerBoard = mutableStateListOf<BoardUnit?>(null, null, null)
    val enemyBoard = mutableStateListOf<BoardUnit?>(null, null, null)
    val log = mutableStateListOf<String>()

    private val remainingDeck = mutableListOf<CardTemplate>()
    private val enemyDeck = mutableListOf<CardTemplate>()

    init {
        remainingDeck.addAll(playerDeck.shuffled())
        repeat(5) { drawCard() }
        // Deck ennemi généré aléatoirement, difficulté proche du niveau du joueur
        val pool = com.romino.mythocards.data.CardDatabase.allCards
        enemyDeck.addAll(pool.shuffled().take(12))
        addLog("Le combat commence !")
    }

    private fun drawCard() {
        if (remainingDeck.isEmpty()) return
        hand.add(remainingDeck.removeAt(0))
    }

    fun canPlay(card: CardTemplate): Boolean = card.cost <= mana && playerBoard.any { it == null }

    fun playCard(handIndex: Int) {
        if (turn != Turn.JOUEUR || gameOver) return
        val card = hand.getOrNull(handIndex) ?: return
        if (!canPlay(card)) return
        val slot = playerBoard.indexOfFirst { it == null }
        if (slot == -1) return
        playerBoard[slot] = BoardUnit(card, card.defense)
        mana -= card.cost
        hand.removeAt(handIndex)
        addLog("Vous invoquez ${card.name}.")
    }

    /** targetSlot == null => attaque directe des points de vie adverses */
    fun attack(sourceSlot: Int, targetSlot: Int?) {
        if (turn != Turn.JOUEUR || gameOver) return
        val attacker = playerBoard[sourceSlot] ?: return
        if (attacker.hasAttacked) return

        if (targetSlot == null) {
            enemyHealth -= attacker.template.attack
            addLog("${attacker.template.name} frappe directement pour ${attacker.template.attack} dégâts.")
        } else {
            val defender = enemyBoard[targetSlot] ?: return
            defender.currentHealth -= attacker.template.attack
            addLog("${attacker.template.name} affronte ${defender.template.name}.")
            attacker.currentHealth -= defender.template.attack
            if (defender.currentHealth <= 0) {
                enemyBoard[targetSlot] = null
                addLog("${defender.template.name} est vaincu.")
            }
            if (attacker.currentHealth <= 0) {
                playerBoard[sourceSlot] = null
                addLog("${attacker.template.name} tombe au combat.")
            }
        }
        playerBoard[sourceSlot] = playerBoard[sourceSlot]?.copy()?.also { it.hasAttacked = true }
        checkGameOver()
    }

    fun endTurn() {
        if (turn != Turn.JOUEUR || gameOver) return
        turn = Turn.ENNEMI
        runEnemyTurn()
    }

    private fun runEnemyTurn() {
        turnNumber += 1
        maxMana = (maxMana + 1).coerceAtMost(10)
        mana = maxMana

        // L'ennemi pioche et joue une carte s'il a de la place et assez de mana
        val enemyMana = (turnNumber / 2 + 1).coerceAtMost(10)
        var manaLeft = enemyMana
        val playable = enemyDeck.shuffled()
        for (card in playable) {
            val slot = enemyBoard.indexOfFirst { it == null }
            if (slot == -1) break
            if (card.cost <= manaLeft) {
                enemyBoard[slot] = BoardUnit(card, card.defense)
                manaLeft -= card.cost
                addLog("L'adversaire invoque ${card.name}.")
            }
        }

        // Les créatures ennemies attaquent
        for (i in enemyBoard.indices) {
            val unit = enemyBoard[i] ?: continue
            val targetSlot = playerBoard.indexOfFirst { it != null }
            if (targetSlot == -1) {
                playerHealth -= unit.template.attack
                addLog("${unit.template.name} attaque directement pour ${unit.template.attack} dégâts.")
            } else {
                val defender = playerBoard[targetSlot]!!
                defender.currentHealth -= unit.template.attack
                unit.currentHealth -= defender.template.attack
                addLog("${unit.template.name} attaque ${defender.template.name}.")
                if (defender.currentHealth <= 0) {
                    playerBoard[targetSlot] = null
                    addLog("${defender.template.name} est vaincu.")
                }
                if (unit.currentHealth <= 0) {
                    enemyBoard[i] = null
                    addLog("${unit.template.name} tombe au combat.")
                }
            }
        }

        checkGameOver()
        if (!gameOver) {
            // Retour au joueur
            turn = Turn.JOUEUR
            playerBoard.replaceAll { it?.copy()?.also { u -> u.hasAttacked = false } }
            drawCard()
            addLog("À vous de jouer.")
        }
    }

    private fun checkGameOver() {
        if (enemyHealth <= 0) {
            gameOver = true
            playerWon = true
            goldReward = 80 + turnNumber * 5
            addLog("Victoire ! Vous remportez $goldReward pièces d'or.")
        } else if (playerHealth <= 0) {
            gameOver = true
            playerWon = false
            addLog("Défaite... l'adversaire était trop puissant.")
        }
    }

    private fun addLog(message: String) {
        log.add(0, message)
        if (log.size > 30) log.removeAt(log.lastIndex)
    }
}
