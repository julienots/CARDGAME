package com.romino.mythocards.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.romino.mythocards.model.BoardUnit
import com.romino.mythocards.model.CardTemplate
import com.romino.mythocards.model.Rarity
import com.romino.mythocards.model.Turn

const val MAX_HEALTH = 30

/**
 * Moteur de combat tour par tour façon jeu de cartes à collectionner :
 * chaque joueur pose des créatures sur un plateau de 3 emplacements et
 * attaque soit une créature adverse, soit directement le point de vie adverse.
 */
class BattleController(playerDeck: List<CardTemplate>) {

    var playerHealth by mutableIntStateOf(30)
    var enemyHealth by mutableIntStateOf(30)
    var mana by mutableIntStateOf(1)
    var maxMana by mutableIntStateOf(1)
    var turn by mutableStateOf(Turn.JOUEUR)
    var turnNumber by mutableIntStateOf(1)
    var gameOver by mutableStateOf(false)
    var playerWon by mutableStateOf(false)
    var goldReward by mutableIntStateOf(0)

    val hand = mutableStateListOf<CardTemplate>()
    val playerBoard = mutableStateListOf<BoardUnit?>(null, null, null)
    val enemyBoard = mutableStateListOf<BoardUnit?>(null, null, null)
    val log = mutableStateListOf<String>()

    private val remainingDeck = mutableListOf<CardTemplate>()
    private val enemyDeck = mutableListOf<CardTemplate>()

    init {
        remainingDeck.addAll(playerDeck.shuffled())
        repeat(5) { drawCard() }
        // Deck ennemi généré aléatoirement, difficulté proche du niveau du joueur
        // Tirage pondéré : l'adversaire peut (rarement) sortir une carte ultra-rare
        repeat(12) { enemyDeck.add(CardDatabase.randomCard()) }
        addLog("Le combat commence !")
    }

    private fun drawCard() {
        if (remainingDeck.isEmpty()) return
        hand.add(remainingDeck.removeAt(0))
    }

    fun canPlay(card: CardTemplate): Boolean = card.cost <= mana && playerBoard.any { it == null }

    fun playCard(handIndex: Int) {
        if (turn != Turn.JOUEUR || gameOver) return
        val card = hand.getOrNull(handIndex) ?: return
        if (!canPlay(card)) return
        val slot = playerBoard.indexOfFirst { it == null }
        if (slot == -1) return
        playerBoard[slot] = BoardUnit(card, card.defense)
        mana -= card.cost
        hand.removeAt(handIndex)
        addLog("Vous invoquez ${card.name}.")
        onSummon(card, byPlayer = true)
        checkGameOver()
    }

    /** targetSlot == null => attaque directe des points de vie adverses */
    fun attack(sourceSlot: Int, targetSlot: Int?) {
        if (turn != Turn.JOUEUR || gameOver) return
        val attacker = playerBoard[sourceSlot] ?: return
        if (attacker.hasAttacked) return

        if (targetSlot == null) {
            enemyHealth -= attacker.template.attack
            addLog("${attacker.template.name} frappe directement pour ${attacker.template.attack} dégâts.")
            lifesteal(attacker.template, attacker.template.attack, byPlayer = true)
        } else {
            val defender = enemyBoard[targetSlot] ?: return
            defender.currentHealth -= attacker.template.attack
            addLog("${attacker.template.name} affronte ${defender.template.name}.")
            lifesteal(attacker.template, attacker.template.attack, byPlayer = true)
            attacker.currentHealth -= defender.template.attack
            lifesteal(defender.template, defender.template.attack, byPlayer = false)
            if (defender.currentHealth <= 0) {
                enemyBoard[targetSlot] = null
                addLog("${defender.template.name} est vaincu.")
            }
            if (attacker.currentHealth <= 0) {
                playerBoard[sourceSlot] = null
                addLog("${attacker.template.name} tombe au combat.")
            }
        }
        playerBoard[sourceSlot] = playerBoard[sourceSlot]?.copy()?.also { it.hasAttacked = true }
        checkGameOver()
    }

    fun endTurn() {
        if (turn != Turn.JOUEUR || gameOver) return
        turn = Turn.ENNEMI
        runEnemyTurn()
    }

    private fun runEnemyTurn() {
        turnNumber += 1
        maxMana = (maxMana + 1).coerceAtMost(10)
        mana = maxMana

        // L'ennemi pioche et joue une carte s'il a de la place et assez de mana
        val enemyMana = (turnNumber / 2 + 1).coerceAtMost(10)
        var manaLeft = enemyMana
        val playable = enemyDeck.shuffled()
        for (card in playable) {
            val slot = enemyBoard.indexOfFirst { it == null }
            if (slot == -1) break
            if (card.cost <= manaLeft) {
                enemyBoard[slot] = BoardUnit(card, card.defense)
                manaLeft -= card.cost
                addLog("L'adversaire invoque ${card.name}.")
                onSummon(card, byPlayer = false)
            }
        }

        // Régénération des Symbiots ennemis
        regenerateSymbiots(enemyBoard)

        // Les créatures ennemies attaquent
        for (i in enemyBoard.indices) {
            if (gameOver) break
            val unit = enemyBoard[i] ?: continue
            val targetSlot = playerBoard.indexOfFirst { it != null }
            if (targetSlot == -1) {
                playerHealth -= unit.template.attack
                addLog("${unit.template.name} attaque directement pour ${unit.template.attack} dégâts.")
                lifesteal(unit.template, unit.template.attack, byPlayer = false)
            } else {
                val defender = playerBoard[targetSlot]!!
                defender.currentHealth -= unit.template.attack
                unit.currentHealth -= defender.template.attack
                addLog("${unit.template.name} attaque ${defender.template.name}.")
                lifesteal(unit.template, unit.template.attack, byPlayer = false)
                lifesteal(defender.template, defender.template.attack, byPlayer = true)
                if (defender.currentHealth <= 0) {
                    playerBoard[targetSlot] = null
                    addLog("${defender.template.name} est vaincu.")
                }
                if (unit.currentHealth <= 0) {
                    enemyBoard[i] = null
                    addLog("${unit.template.name} tombe au combat.")
                }
            }
            checkGameOver()
        }

        checkGameOver()
        if (!gameOver) {
            // Retour au joueur
            turn = Turn.JOUEUR
            regenerateSymbiots(playerBoard)
            playerBoard.replaceAll { it?.copy()?.also { u -> u.hasAttacked = false } }
            drawCard()
            addLog("À vous de jouer.")
        }
    }

    /** Pouvoirs déclenchés à l'invocation des raretés ultra. */
    private fun onSummon(card: CardTemplate, byPlayer: Boolean) {
        when (card.rarity) {
            Rarity.DIVIN -> {
                if (byPlayer) playerHealth = (playerHealth + 5).coerceAtMost(MAX_HEALTH)
                else enemyHealth = (enemyHealth + 5).coerceAtMost(MAX_HEALTH)
                addLog("✨ Bénédiction de ${card.name} : +5 PV.")
            }
            Rarity.COSMIQUE -> {
                if (byPlayer) enemyHealth -= 5 else playerHealth -= 5
                addLog("☄️ Météore de ${card.name} : 5 dégâts directs !")
            }
            Rarity.PRIMORDIAL -> {
                val targets = if (byPlayer) enemyBoard else playerBoard
                for (i in targets.indices) {
                    val u = targets[i] ?: continue
                    u.currentHealth -= 8
                    targets[i] = if (u.currentHealth <= 0) {
                        addLog("${u.template.name} est anéanti par le Cataclysme.")
                        null
                    } else u.copy()
                }
                addLog("🌋 Cataclysme de ${card.name} : 8 dégâts à tous les ennemis !")
            }
            else -> Unit
        }
    }

    /** Les Symbiots rendent à leur maître les dégâts qu'ils infligent. */
    private fun lifesteal(card: CardTemplate, damage: Int, byPlayer: Boolean) {
        if (card.rarity != Rarity.SYMBIOT) return
        if (byPlayer) playerHealth = (playerHealth + damage).coerceAtMost(MAX_HEALTH)
        else enemyHealth = (enemyHealth + damage).coerceAtMost(MAX_HEALTH)
        addLog("🧬 Symbiose : ${card.name} absorbe $damage PV.")
    }

    /** Les Symbiots survivants récupèrent toute leur défense. */
    private fun regenerateSymbiots(board: MutableList<BoardUnit?>) {
        for (i in board.indices) {
            val u = board[i] ?: continue
            if (u.template.rarity == Rarity.SYMBIOT && u.currentHealth < u.template.defense) {
                board[i] = u.copy(currentHealth = u.template.defense)
            }
        }
    }

    private fun checkGameOver() {
        if (gameOver) return
        if (enemyHealth <= 0) {
            gameOver = true
            playerWon = true
            goldReward = 120 + turnNumber * 8
            addLog("Victoire ! Vous remportez $goldReward pièces d'or.")
        } else if (playerHealth <= 0) {
            gameOver = true
            playerWon = false
            addLog("Défaite... l'adversaire était trop puissant.")
        }
    }

    private fun addLog(message: String) {
        log.add(0, message)
        if (log.size > 30) log.removeAt(log.lastIndex)
    }
}
