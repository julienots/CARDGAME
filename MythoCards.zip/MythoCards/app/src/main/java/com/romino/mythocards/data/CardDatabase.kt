package com.romino.mythocards.data

import com.romino.mythocards.model.CardSymbol
import com.romino.mythocards.model.CardTemplate
import com.romino.mythocards.model.Rarity

object CardDatabase {

    val curatedCards: List<CardTemplate> = listOf(
        // ---- COMMUN ----
        CardTemplate("c01", "Loup des Plaines", Rarity.COMMUN, 1, 2, 2, CardSymbol.LOUP, "Chasse en meute dès l'aube."),
        CardTemplate("c02", "Golem d'Argile", Rarity.COMMUN, 2, 2, 4, CardSymbol.GOLEM, "Façonné par des mains oubliées."),
        CardTemplate("c03", "Serpent des Sables", Rarity.COMMUN, 1, 3, 1, CardSymbol.SERPENT, "Son venin engourdit en un instant."),
        CardTemplate("c04", "Spectre Errant", Rarity.COMMUN, 2, 3, 2, CardSymbol.SPECTRE, "Il hante les ruines depuis des siècles."),
        CardTemplate("c05", "Griffon Sauvageon", Rarity.COMMUN, 3, 3, 3, CardSymbol.GRIFFON, "Trop jeune pour voler bien haut."),
        CardTemplate("c06", "Petit Kraken", Rarity.COMMUN, 2, 2, 3, CardSymbol.KRAKEN, "Ses tentacules grandissent chaque année."),
        CardTemplate("c07", "Loup Solitaire", Rarity.COMMUN, 1, 1, 3, CardSymbol.LOUP, "Banni de la meute, il survit seul."),
        CardTemplate("c08", "Golem de Pierre", Rarity.COMMUN, 3, 2, 5, CardSymbol.GOLEM, "Immobile mais increvable."),
        CardTemplate("c09", "Démon Mineur", Rarity.COMMUN, 2, 3, 1, CardSymbol.DEMON, "Un simple messager des Abysses."),
        CardTemplate("c10", "Ange Novice", Rarity.COMMUN, 2, 2, 2, CardSymbol.ANGE, "Ses ailes ne sont pas encore déployées."),
        CardTemplate("c11", "Hydre Naissante", Rarity.COMMUN, 3, 3, 4, CardSymbol.HYDRE, "Une seule tête, pour l'instant."),
        CardTemplate("c12", "Dragonneau", Rarity.COMMUN, 2, 3, 3, CardSymbol.DRAGON, "Son souffle n'est encore qu'un filet de fumée."),

        // ---- RARE ----
        CardTemplate("r01", "Loup de Givre", Rarity.RARE, 3, 4, 4, CardSymbol.LOUP, "Chaque pas gèle le sol."),
        CardTemplate("r02", "Golem de Fer", Rarity.RARE, 4, 4, 6, CardSymbol.GOLEM, "Forgé dans les mines profondes."),
        CardTemplate("r03", "Vipère Écarlate", Rarity.RARE, 3, 5, 2, CardSymbol.SERPENT, "Une morsure suffit."),
        CardTemplate("r04", "Spectre Hurlant", Rarity.RARE, 3, 4, 3, CardSymbol.SPECTRE, "Son cri glace le sang."),
        CardTemplate("r05", "Griffon des Cimes", Rarity.RARE, 4, 5, 4, CardSymbol.GRIFFON, "Maître des courants ascendants."),
        CardTemplate("r06", "Kraken des Profondeurs", Rarity.RARE, 5, 5, 6, CardSymbol.KRAKEN, "Les marins évitent ces eaux."),
        CardTemplate("r07", "Démon Cornu", Rarity.RARE, 4, 5, 3, CardSymbol.DEMON, "Ses griffes déchirent l'acier."),
        CardTemplate("r08", "Ange Gardien", Rarity.RARE, 4, 3, 5, CardSymbol.ANGE, "Protège les âmes égarées."),
        CardTemplate("r09", "Hydre à Deux Têtes", Rarity.RARE, 5, 5, 5, CardSymbol.HYDRE, "Coupez une tête, une autre mord."),
        CardTemplate("r10", "Jeune Dragon Rouge", Rarity.RARE, 5, 6, 4, CardSymbol.DRAGON, "Son souffle embrase déjà les prairies."),

        // ---- ÉPIQUE ----
        CardTemplate("e01", "Alpha des Neiges Éternelles", Rarity.EPIQUE, 5, 7, 6, CardSymbol.LOUP, "Chef d'une meute légendaire."),
        CardTemplate("e02", "Colosse de Titane", Rarity.EPIQUE, 6, 6, 9, CardSymbol.GOLEM, "Aucune lame ne l'a jamais percé."),
        CardTemplate("e03", "Basilic des Cavernes", Rarity.EPIQUE, 5, 8, 3, CardSymbol.SERPENT, "Son regard pétrifie l'audacieux."),
        CardTemplate("e04", "Spectre du Néant", Rarity.EPIQUE, 5, 6, 5, CardSymbol.SPECTRE, "Il se nourrit des souvenirs perdus."),
        CardTemplate("e05", "Griffon Royal", Rarity.EPIQUE, 6, 7, 6, CardSymbol.GRIFFON, "Monture des anciens rois."),
        CardTemplate("e06", "Kraken Tempête", Rarity.EPIQUE, 7, 8, 7, CardSymbol.KRAKEN, "Ses tentacules déchaînent les vagues."),
        CardTemplate("e07", "Archidémon", Rarity.EPIQUE, 6, 8, 5, CardSymbol.DEMON, "Commande les légions infernales."),
        CardTemplate("e08", "Séraphin Vengeur", Rarity.EPIQUE, 6, 6, 7, CardSymbol.ANGE, "La justice divine incarnée."),

        // ---- LÉGENDAIRE ----
        CardTemplate("l01", "Fenrir, l'Ombre Dévorante", Rarity.LEGENDAIRE, 8, 10, 8, CardSymbol.LOUP, "Prophétisé pour engloutir le soleil."),
        CardTemplate("l02", "Atlas, le Porteur de Mondes", Rarity.LEGENDAIRE, 9, 8, 12, CardSymbol.GOLEM, "Il soutient le ciel sur ses épaules de pierre."),
        CardTemplate("l03", "Jörmungandr Ancestral", Rarity.LEGENDAIRE, 9, 11, 7, CardSymbol.SERPENT, "Le serpent qui enserre le monde."),
        CardTemplate("l04", "Léviathan des Abysses", Rarity.LEGENDAIRE, 10, 11, 10, CardSymbol.KRAKEN, "Une seule vague suffit à effacer une flotte."),
        CardTemplate("l05", "Baalzur, Seigneur des Flammes Noires", Rarity.LEGENDAIRE, 9, 11, 8, CardSymbol.DEMON, "Son trône est fait de crânes calcinés."),
        CardTemplate("l06", "Ignis Rex, Roi Dragon", Rarity.LEGENDAIRE, 10, 12, 9, CardSymbol.DRAGON, "Son règne a duré mille ans de cendres."),

        // ---- MYTHIQUE ----
        CardTemplate("m01", "Aeon, l'Œil du Temps", Rarity.MYTHIQUE, 10, 13, 12, CardSymbol.SPECTRE, "Il a vu naître et mourir des univers entiers."),
        CardTemplate("m02", "Solacielle, Genèse Ailée", Rarity.MYTHIQUE, 10, 12, 13, CardSymbol.ANGE, "Née du premier rayon de lumière."),
        CardTemplate("m03", "Nyxdrath, le Dévoreur d'Étoiles", Rarity.MYTHIQUE, 10, 14, 12, CardSymbol.DRAGON, "Chaque nuit sans étoiles est son œuvre."),

        // ================== EXTENSION « ÉVEIL SYMBIOTIQUE » ==================

        // ---- COMMUN (nouveaux) ----
        CardTemplate("c13", "Larve Symbiotique", Rarity.COMMUN, 1, 2, 1, CardSymbol.SYMBIOTE, "Elle cherche un hôte, n'importe lequel."),
        CardTemplate("c14", "Chimérion", Rarity.COMMUN, 2, 3, 2, CardSymbol.CHIMERE, "Trois têtes, aucune ne s'entend."),
        CardTemplate("c15", "Squelette Apprenti", Rarity.COMMUN, 1, 1, 2, CardSymbol.LICHE, "Il révise encore ses sortilèges."),
        CardTemplate("c16", "Phénix de Braise", Rarity.COMMUN, 2, 2, 3, CardSymbol.PHOENIX, "Une étincelle qui refuse de s'éteindre."),
        CardTemplate("c17", "Titan de Galets", Rarity.COMMUN, 3, 2, 5, CardSymbol.TITAN, "Petit pour un titan, énorme pour un homme."),
        CardTemplate("c18", "Gelée Vivante", Rarity.COMMUN, 2, 2, 4, CardSymbol.SYMBIOTE, "Elle absorbe tout ce qu'elle touche."),

        // ---- RARE (nouveaux) ----
        CardTemplate("r11", "Parasite Noir", Rarity.RARE, 3, 5, 3, CardSymbol.SYMBIOTE, "Il s'accroche à l'âme de son porteur."),
        CardTemplate("r12", "Chimère des Marais", Rarity.RARE, 4, 5, 5, CardSymbol.CHIMERE, "Le lion, la chèvre et le serpent chassent ensemble."),
        CardTemplate("r13", "Liche Mineure", Rarity.RARE, 4, 6, 3, CardSymbol.LICHE, "Son phylactère est caché dans une simple bague."),
        CardTemplate("r14", "Phénix Cendré", Rarity.RARE, 4, 5, 4, CardSymbol.PHOENIX, "Il renaît plus fort à chaque chute."),
        CardTemplate("r15", "Titan des Collines", Rarity.RARE, 5, 5, 7, CardSymbol.TITAN, "Les collines sont ses anciens frères endormis."),
        CardTemplate("r16", "Hôte Contaminé", Rarity.RARE, 3, 4, 5, CardSymbol.SYMBIOTE, "Il n'est plus tout à fait lui-même."),

        // ---- ÉPIQUE (nouveaux) ----
        CardTemplate("e09", "Venomorphe", Rarity.EPIQUE, 6, 9, 6, CardSymbol.SYMBIOTE, "Une armure vivante qui a faim."),
        CardTemplate("e10", "Chimère Royale", Rarity.EPIQUE, 6, 8, 8, CardSymbol.CHIMERE, "Gardienne des trésors du roi fou."),
        CardTemplate("e11", "Liche du Crépuscule", Rarity.EPIQUE, 6, 9, 5, CardSymbol.LICHE, "Elle a échangé son cœur contre l'éternité."),
        CardTemplate("e12", "Phénix Écarlate", Rarity.EPIQUE, 6, 8, 7, CardSymbol.PHOENIX, "Ses plumes sont des braises éternelles."),
        CardTemplate("e13", "Titan de Bronze", Rarity.EPIQUE, 7, 7, 11, CardSymbol.TITAN, "Il garde le détroit depuis l'aube des temps."),
        CardTemplate("e14", "Hydre Venimeuse", Rarity.EPIQUE, 7, 9, 8, CardSymbol.HYDRE, "Neuf têtes, neuf poisons."),

        // ---- LÉGENDAIRE (nouveaux) ----
        CardTemplate("l07", "Carnaxis, le Symbiote Rouge", Rarity.LEGENDAIRE, 9, 13, 9, CardSymbol.SYMBIOTE, "Il ne laisse que des carcasses vides."),
        CardTemplate("l08", "Kel'Thar, Liche Suprême", Rarity.LEGENDAIRE, 9, 12, 10, CardSymbol.LICHE, "Mille nécromanciens ont juré de la servir."),
        CardTemplate("l09", "Phénix Solaire", Rarity.LEGENDAIRE, 9, 11, 11, CardSymbol.PHOENIX, "Son envol fait se lever le jour."),
        CardTemplate("l10", "Chronos le Titan", Rarity.LEGENDAIRE, 10, 11, 14, CardSymbol.TITAN, "Il dévore les heures et recrache les siècles."),
        CardTemplate("l11", "Chimère Abyssale", Rarity.LEGENDAIRE, 10, 13, 11, CardSymbol.CHIMERE, "Toutes les bêtes du monde fondues en une."),

        // ---- MYTHIQUE (nouveaux) ----
        CardTemplate("m04", "Ouroboros Infini", Rarity.MYTHIQUE, 10, 15, 14, CardSymbol.SERPENT, "Il se dévore lui-même pour l'éternité."),
        CardTemplate("m05", "Ymir, Premier des Titans", Rarity.MYTHIQUE, 10, 14, 17, CardSymbol.TITAN, "De sa chair naquirent les montagnes."),
        CardTemplate("m06", "Mortiva, Reine des Liches", Rarity.MYTHIQUE, 10, 16, 13, CardSymbol.LICHE, "La mort elle-même lui obéit."),
        CardTemplate("m07", "Phénix de l'Aube Éternelle", Rarity.MYTHIQUE, 10, 15, 15, CardSymbol.PHOENIX, "Chaque cendre est une promesse de renaissance."),
        CardTemplate("m08", "Abyssal, l'Hôte Ultime", Rarity.MYTHIQUE, 10, 17, 12, CardSymbol.SYMBIOTE, "Le dernier stade avant la symbiose parfaite."),

        // ---- DIVIN ---- (À l'invocation : soigne son maître de 5 PV)
        CardTemplate("d01", "Elyon, Lumière Première", Rarity.DIVIN, 8, 18, 18, CardSymbol.ANGE, "Avant lui, il n'y avait que la nuit."),
        CardTemplate("d02", "Garuda Céleste", Rarity.DIVIN, 8, 19, 16, CardSymbol.GRIFFON, "Ses ailes couvrent l'horizon tout entier."),
        CardTemplate("d03", "Bahamut, Dragon Sacré", Rarity.DIVIN, 9, 21, 18, CardSymbol.DRAGON, "Le roi de tous les dragons, juge des cieux."),
        CardTemplate("d04", "Hélios Renaissant", Rarity.DIVIN, 8, 18, 19, CardSymbol.PHOENIX, "Le soleil lui-même est son nid."),
        CardTemplate("d05", "Gaïa, Mère des Golems", Rarity.DIVIN, 9, 16, 24, CardSymbol.GOLEM, "Chaque montagne est l'un de ses enfants."),
        CardTemplate("d06", "Seraphiel l'Incorruptible", Rarity.DIVIN, 9, 20, 20, CardSymbol.ANGE, "Aucun péché ne résiste à son regard."),

        // ---- COSMIQUE ---- (À l'invocation : 5 dégâts directs à l'adversaire)
        CardTemplate("k01", "Nébulor, Dévoreur de Galaxies", Rarity.COSMIQUE, 9, 25, 22, CardSymbol.KRAKEN, "Ses tentacules s'étendent entre les étoiles."),
        CardTemplate("k02", "Astraeus, Loup Stellaire", Rarity.COSMIQUE, 9, 26, 20, CardSymbol.LOUP, "Il hurle et les comètes changent de cap."),
        CardTemplate("k03", "Quasaris, Hydre des Pulsars", Rarity.COSMIQUE, 10, 27, 24, CardSymbol.HYDRE, "Chaque tête est une étoile à neutrons."),
        CardTemplate("k04", "Voidmaw, Bouche du Vide", Rarity.COSMIQUE, 9, 28, 19, CardSymbol.DEMON, "Il a avalé trois soleils et a encore faim."),
        CardTemplate("k05", "Orion, Titan des Constellations", Rarity.COSMIQUE, 10, 24, 30, CardSymbol.TITAN, "Les étoiles dessinent son armure."),
        CardTemplate("k06", "Éclipse, Spectre Astral", Rarity.COSMIQUE, 9, 25, 23, CardSymbol.SPECTRE, "Là où il passe, la lumière meurt."),

        // ---- PRIMORDIAL ---- (À l'invocation : 8 dégâts à toutes les créatures ennemies)
        CardTemplate("p01", "Chaos, l'Avant-Monde", Rarity.PRIMORDIAL, 10, 34, 32, CardSymbol.SPECTRE, "Il était là avant le premier souffle."),
        CardTemplate("p02", "Tiamat, Mère des Monstres", Rarity.PRIMORDIAL, 10, 36, 30, CardSymbol.HYDRE, "De son sang naquirent tous les dragons."),
        CardTemplate("p03", "Ignarok, Flamme Originelle", Rarity.PRIMORDIAL, 10, 38, 28, CardSymbol.DRAGON, "Le premier feu, celui qui forgea les astres."),
        CardTemplate("p04", "Abzu, Océan Premier", Rarity.PRIMORDIAL, 10, 33, 36, CardSymbol.KRAKEN, "Toutes les mers ne sont que ses larmes."),
        CardTemplate("p05", "Nekron, Liche Primordiale", Rarity.PRIMORDIAL, 10, 37, 31, CardSymbol.LICHE, "Il a inventé la mort pour s'amuser."),

        // ---- SYMBIOT ---- (Vol de vie + régénération complète à chaque tour)
        CardTemplate("s01", "VENOM-X, Symbiote Alpha", Rarity.SYMBIOT, 10, 50, 45, CardSymbol.SYMBIOTE, "Il n'a pas d'hôte. Il EST l'hôte."),
        CardTemplate("s02", "Carnage Éternel", Rarity.SYMBIOT, 10, 58, 38, CardSymbol.SYMBIOTE, "Une symbiose de pure destruction."),
        CardTemplate("s03", "Nyxdrath Symbiotique", Rarity.SYMBIOT, 10, 55, 50, CardSymbol.DRAGON, "Le Dévoreur d'Étoiles a trouvé plus affamé que lui."),
        CardTemplate("s04", "Fenrir Fusionné", Rarity.SYMBIOT, 10, 52, 44, CardSymbol.LOUP, "La bête et le parasite ne font plus qu'un."),
        CardTemplate("s05", "Léviathan Hôte-Abîme", Rarity.SYMBIOT, 10, 48, 60, CardSymbol.KRAKEN, "Ses tentacules sont désormais vivants."),
        CardTemplate("s06", "Séraphin Corrompu", Rarity.SYMBIOT, 10, 54, 48, CardSymbol.ANGE, "Ses ailes blanches sont devenues noires et vivantes."),
        CardTemplate("s07", "Chimère Symbiotique Ω", Rarity.SYMBIOT, 10, 60, 55, CardSymbol.CHIMERE, "Toutes les créatures, un seul esprit."),
        CardTemplate("s08", "L'Essaim-Roi", Rarity.SYMBIOT, 10, 65, 65, CardSymbol.SYMBIOTE, "La forme finale. Rien ne lui survit.")
    )

    /** Pouvoir spécial en combat selon la rareté (raretés ultra uniquement). */
    fun abilityText(rarity: Rarity): String? = when (rarity) {
        Rarity.DIVIN -> "Bénédiction : +5 PV à l'invocation"
        Rarity.COSMIQUE -> "Météore : 5 dégâts directs à l'invocation"
        Rarity.PRIMORDIAL -> "Cataclysme : 8 dégâts à tous les ennemis"
        Rarity.SYMBIOT -> "Symbiose : vol de vie + régénération totale"
        else -> null
    }

    private val loreByRarity = mapOf(
        Rarity.COMMUN to listOf(
            "Une créature du commun, mais jamais à sous-estimer.",
            "On en croise dans presque chaque contrée du royaume.",
            "Simple mais fiable au combat.",
            "Son espèce peuple les terres depuis des générations."
        ),
        Rarity.RARE to listOf(
            "Peu de dresseurs peuvent se vanter d'en avoir capturé une.",
            "Sa force dépasse largement celle de ses semblables communs.",
            "On raconte qu'elle choisit elle-même son maître.",
            "Un spécimen recherché par tous les collectionneurs."
        ),
        Rarity.EPIQUE to listOf(
            "Son pouvoir a changé le cours de plusieurs batailles.",
            "Peu osent l'affronter en combat singulier.",
            "Elle porte les cicatrices d'innombrables guerres.",
            "Sa seule présence fait fuir les créatures plus faibles."
        ),
        Rarity.LEGENDAIRE to listOf(
            "Son nom est gravé dans les annales du royaume.",
            "Une seule apparition suffit à changer le destin d'une bataille.",
            "Les anciens textes parlent d'elle comme d'un fléau ou d'un sauveur.",
            "Peu ont survécu pour raconter leur rencontre avec elle."
        ),
        Rarity.MYTHIQUE to listOf(
            "Les dieux eux-mêmes murmurent son nom avec crainte.",
            "Sa légende précède l'écriture.",
            "Elle n'apparaît qu'une fois par millénaire."
        ),
        Rarity.DIVIN to listOf(
            "Une étincelle du divin descendue parmi les mortels.",
            "Sa lumière purifie tout ce qu'elle touche.",
            "Les temples entiers lui sont consacrés."
        ),
        Rarity.COSMIQUE to listOf(
            "Venue d'au-delà des étoiles, elle ne connaît aucune limite.",
            "Les galaxies tournent autour de sa volonté.",
            "Son ombre recouvre des systèmes solaires entiers."
        ),
        Rarity.PRIMORDIAL to listOf(
            "Elle existait avant la création du monde.",
            "Le temps et l'espace sont nés de son premier souffle.",
            "Même les dieux sont ses descendants."
        ),
        Rarity.SYMBIOT to listOf(
            "Une fusion parfaite entre la bête et le symbiote. Inarrêtable.",
            "Le symbiote a trouvé son hôte idéal. Plus rien ne les séparera.",
            "Chaque blessure la rend plus forte. Chaque victime la nourrit."
        )
    )

    private val symbolLabel = mapOf(
        CardSymbol.DRAGON to "Dragon",
        CardSymbol.PHOENIX to "Phénix",
        CardSymbol.GOLEM to "Golem",
        CardSymbol.SPECTRE to "Spectre",
        CardSymbol.KRAKEN to "Kraken",
        CardSymbol.LOUP to "Loup",
        CardSymbol.SERPENT to "Serpent",
        CardSymbol.TITAN to "Titan",
        CardSymbol.DEMON to "Démon",
        CardSymbol.ANGE to "Ange",
        CardSymbol.HYDRE to "Hydre",
        CardSymbol.GRIFFON to "Griffon",
        CardSymbol.SYMBIOTE to "Symbiote",
        CardSymbol.CHIMERE to "Chimère",
        CardSymbol.LICHE to "Liche"
    )

    private val adjectivesByRarity = mapOf(
        Rarity.COMMUN to listOf(
            "des Prairies", "du Vieux Chemin", "de la Clairière", "des Terres Grises",
            "du Marécage", "des Roseaux", "de la Vallée Calme", "des Pierres Grises",
            "du Bois Mort", "des Terres Arides"
        ),
        Rarity.RARE to listOf(
            "des Vents Glacés", "de l'Orage Pourpre", "des Récifs Noirs", "de la Lame Brisée",
            "des Cendres Vives", "du Crépuscule", "des Flammes Bleues", "de la Marée Haute",
            "des Pics Gelés", "du Sable Mouvant"
        ),
        Rarity.EPIQUE to listOf(
            "du Chaos Ancien", "des Larmes de Sang", "de l'Éclipse Totale", "des Ombres Rampantes",
            "du Trône Brisé", "des Cieux Déchirés", "de la Faille Béante", "des Âmes Errantes",
            "du Volcan Endormi", "des Étoiles Mortes"
        ),
        Rarity.LEGENDAIRE to listOf(
            "le Ravageur des Âges", "l'Immuable", "le Briseur de Serments",
            "le Cœur des Tempêtes", "le Dernier Rempart", "l'Oublié des Dieux"
        ),
        Rarity.MYTHIQUE to listOf("l'Éternel", "le Sans-Fin", "Fléau des Mondes"),
        Rarity.DIVIN to listOf("Sacré", "l'Illuminé", "Main des Dieux", "le Béni"),
        Rarity.COSMIQUE to listOf("des Nébuleuses", "Stellaire", "du Trou Noir", "des Supernovas"),
        Rarity.PRIMORDIAL to listOf("Originel", "de l'Avant-Temps", "le Premier-Né"),
        Rarity.SYMBIOT to listOf("Symbiotique", "Fusionné", "Hôte-Absolu", "Parasite-Roi")
    )

    private val statVariants = mapOf(
        Rarity.COMMUN to listOf(Triple(1, 1, 2), Triple(1, 2, 1), Triple(2, 2, 3), Triple(2, 3, 2), Triple(3, 2, 4), Triple(1, 3, 1)),
        Rarity.RARE to listOf(Triple(3, 4, 3), Triple(3, 3, 5), Triple(4, 5, 4), Triple(4, 4, 6), Triple(5, 5, 3), Triple(5, 6, 2)),
        Rarity.EPIQUE to listOf(Triple(5, 6, 5), Triple(5, 7, 4), Triple(6, 7, 6), Triple(6, 8, 5), Triple(7, 8, 7), Triple(7, 7, 9)),
        Rarity.LEGENDAIRE to listOf(Triple(8, 9, 9), Triple(8, 10, 8), Triple(9, 10, 10), Triple(9, 11, 9), Triple(10, 11, 11), Triple(10, 12, 10)),
        Rarity.MYTHIQUE to listOf(Triple(10, 13, 13), Triple(10, 14, 12), Triple(10, 15, 11), Triple(10, 12, 15)),
        Rarity.DIVIN to listOf(Triple(8, 17, 17), Triple(8, 18, 15), Triple(9, 19, 18), Triple(9, 16, 21)),
        Rarity.COSMIQUE to listOf(Triple(9, 22, 20), Triple(9, 24, 19), Triple(10, 25, 23), Triple(10, 21, 27)),
        Rarity.PRIMORDIAL to listOf(Triple(10, 30, 28), Triple(10, 32, 27), Triple(10, 29, 32)),
        Rarity.SYMBIOT to listOf(Triple(10, 45, 40), Triple(10, 48, 42), Triple(10, 42, 50))
    )

    /** Préfixes d'identifiants des cartes générées (ne JAMAIS changer : ils servent à la sauvegarde). */
    private val idPrefix = mapOf(
        Rarity.COMMUN to "gc", Rarity.RARE to "gr", Rarity.EPIQUE to "ge", Rarity.LEGENDAIRE to "gl",
        Rarity.MYTHIQUE to "gmy", Rarity.DIVIN to "gdv", Rarity.COSMIQUE to "gco",
        Rarity.PRIMORDIAL to "gpr", Rarity.SYMBIOT to "gsy"
    )

    /** Nombre de cartes générées en plus des cartes écrites à la main. */
    private val extraCounts = mapOf(
        Rarity.COMMUN to 88,
        Rarity.RARE to 45,
        Rarity.EPIQUE to 22,
        Rarity.LEGENDAIRE to 6,
        Rarity.MYTHIQUE to 12,
        Rarity.DIVIN to 20,
        Rarity.COSMIQUE to 15,
        Rarity.PRIMORDIAL to 10,
        Rarity.SYMBIOT to 8
    )

    /** Les 12 symboles d'origine : utilisés pour les anciennes raretés afin de garder les mêmes noms de cartes. */
    private val legacySymbols = CardSymbol.entries.take(12)

    private fun generateExtraCards(): List<CardTemplate> {
        val result = mutableListOf<CardTemplate>()
        for ((rarity, count) in extraCounts) {
            val symbols = if (rarity.tier <= Rarity.LEGENDAIRE.tier) legacySymbols else CardSymbol.entries
            val adjectives = adjectivesByRarity.getValue(rarity)
            val variants = statVariants.getValue(rarity)
            val lore = loreByRarity.getValue(rarity)
            var generated = 0
            var symbolIndex = 0
            var adjectiveIndex = 0
            while (generated < count) {
                val symbol = symbols[symbolIndex % symbols.size]
                val adjective = adjectives[adjectiveIndex % adjectives.size]
                val (cost, attack, defense) = variants[generated % variants.size]
                val id = "${idPrefix.getValue(rarity)}${generated + 1}"
                result.add(
                    CardTemplate(
                        id = id,
                        name = "${symbolLabel.getValue(symbol)} $adjective",
                        rarity = rarity,
                        cost = cost,
                        attack = attack,
                        defense = defense,
                        symbol = symbol,
                        lore = lore[generated % lore.size]
                    )
                )
                generated += 1
                symbolIndex += 1
                if (symbolIndex % symbols.size == 0) adjectiveIndex += 1
            }
        }
        return result
    }

    val allCards: List<CardTemplate> = curatedCards + generateExtraCards()

    private val byIdMap: Map<String, CardTemplate> = allCards.associateBy { it.id }
    private val byRarityMap: Map<Rarity, List<CardTemplate>> = allCards.groupBy { it.rarity }

    fun byId(id: String): CardTemplate? = byIdMap[id]

    fun cardsOfRarity(rarity: Rarity): List<CardTemplate> = byRarityMap[rarity].orEmpty()

    /**
     * Tirage pondéré selon les taux de drop.
     * @param luckBoost augmente les chances des raretés élevées (0.0 = normal).
     * @param minRarity rareté minimale garantie pour cette carte.
     */
    fun randomCard(luckBoost: Double = 0.0, minRarity: Rarity = Rarity.COMMUN): CardTemplate {
        val weights = Rarity.entries.filter { it.tier >= minRarity.tier }.map { rarity ->
            val w = when (rarity) {
                Rarity.COMMUN -> (rarity.dropRate - luckBoost * 0.5).coerceAtLeast(0.05)
                Rarity.RARE -> rarity.dropRate
                Rarity.EPIQUE -> rarity.dropRate + luckBoost * 0.25
                Rarity.LEGENDAIRE -> rarity.dropRate + luckBoost * 0.2
                Rarity.MYTHIQUE -> rarity.dropRate + luckBoost * 0.05
                Rarity.DIVIN -> rarity.dropRate + luckBoost * 0.03
                Rarity.COSMIQUE -> rarity.dropRate + luckBoost * 0.02
                Rarity.PRIMORDIAL -> rarity.dropRate + luckBoost * 0.012
                Rarity.SYMBIOT -> rarity.dropRate + luckBoost * 0.006
            }
            rarity to w
        }
        val total = weights.sumOf { it.second }
        val roll = Math.random() * total
        var cumulative = 0.0
        for ((rarity, rate) in weights) {
            cumulative += rate
            if (roll <= cumulative) return cardsOfRarity(rarity).random()
        }
        return cardsOfRarity(weights.last().first).random()
    }

    fun starterDeckIds(): List<String> = listOf("c01", "c02", "c03", "c04", "c05", "c07", "c09", "c10")
}
