package com.romino.mythocards.data

import com.romino.mythocards.model.CardSymbol
import com.romino.mythocards.model.CardTemplate
import com.romino.mythocards.model.Rarity

object CardDatabase {

    val curatedCards: List<CardTemplate> = listOf(
        // ---- COMMUN ----
        CardTemplate("c01", "Loup des Plaines", Rarity.COMMUN, 1, 2, 2, CardSymbol.LOUP, "Chasse en meute dès l'aube."),
        CardTemplate("c02", "Golem d'Argile", Rarity.COMMUN, 2, 2, 4, CardSymbol.GOLEM, "Façonné par des mains oubliées."),
        CardTemplate("c03", "Serpent des Sables", Rarity.COMMUN, 1, 3, 1, CardSymbol.SERPENT, "Son venin engourdit en un instant."),
        CardTemplate("c04", "Spectre Errant", Rarity.COMMUN, 2, 3, 2, CardSymbol.SPECTRE, "Il hante les ruines depuis des siècles."),
        CardTemplate("c05", "Griffon Sauvageon", Rarity.COMMUN, 3, 3, 3, CardSymbol.GRIFFON, "Trop jeune pour voler bien haut."),
        CardTemplate("c06", "Petit Kraken", Rarity.COMMUN, 2, 2, 3, CardSymbol.KRAKEN, "Ses tentacules grandissent chaque année."),
        CardTemplate("c07", "Loup Solitaire", Rarity.COMMUN, 1, 1, 3, CardSymbol.LOUP, "Banni de la meute, il survit seul."),
        CardTemplate("c08", "Golem de Pierre", Rarity.COMMUN, 3, 2, 5, CardSymbol.GOLEM, "Immobile mais increvable."),
        CardTemplate("c09", "Démon Mineur", Rarity.COMMUN, 2, 3, 1, CardSymbol.DEMON, "Un simple messager des Abysses."),
        CardTemplate("c10", "Ange Novice", Rarity.COMMUN, 2, 2, 2, CardSymbol.ANGE, "Ses ailes ne sont pas encore déployées."),
        CardTemplate("c11", "Hydre Naissante", Rarity.COMMUN, 3, 3, 4, CardSymbol.HYDRE, "Une seule tête, pour l'instant."),
        CardTemplate("c12", "Dragonneau", Rarity.COMMUN, 2, 3, 3, CardSymbol.DRAGON, "Son souffle n'est encore qu'un filet de fumée."),

        // ---- RARE ----
        CardTemplate("r01", "Loup de Givre", Rarity.RARE, 3, 4, 4, CardSymbol.LOUP, "Chaque pas gèle le sol."),
        CardTemplate("r02", "Golem de Fer", Rarity.RARE, 4, 4, 6, CardSymbol.GOLEM, "Forgé dans les mines profondes."),
        CardTemplate("r03", "Vipère Écarlate", Rarity.RARE, 3, 5, 2, CardSymbol.SERPENT, "Une morsure suffit."),
        CardTemplate("r04", "Spectre Hurlant", Rarity.RARE, 3, 4, 3, CardSymbol.SPECTRE, "Son cri glace le sang."),
        CardTemplate("r05", "Griffon des Cimes", Rarity.RARE, 4, 5, 4, CardSymbol.GRIFFON, "Maître des courants ascendants."),
        CardTemplate("r06", "Kraken des Profondeurs", Rarity.RARE, 5, 5, 6, CardSymbol.KRAKEN, "Les marins évitent ces eaux."),
        CardTemplate("r07", "Démon Cornu", Rarity.RARE, 4, 5, 3, CardSymbol.DEMON, "Ses griffes déchirent l'acier."),
        CardTemplate("r08", "Ange Gardien", Rarity.RARE, 4, 3, 5, CardSymbol.ANGE, "Protège les âmes égarées."),
        CardTemplate("r09", "Hydre à Deux Têtes", Rarity.RARE, 5, 5, 5, CardSymbol.HYDRE, "Coupez une tête, une autre mord."),
        CardTemplate("r10", "Jeune Dragon Rouge", Rarity.RARE, 5, 6, 4, CardSymbol.DRAGON, "Son souffle embrase déjà les prairies."),

        // ---- ÉPIQUE ----
        CardTemplate("e01", "Alpha des Neiges Éternelles", Rarity.EPIQUE, 5, 7, 6, CardSymbol.LOUP, "Chef d'une meute légendaire."),
        CardTemplate("e02", "Colosse de Titane", Rarity.EPIQUE, 6, 6, 9, CardSymbol.GOLEM, "Aucune lame ne l'a jamais percé."),
        CardTemplate("e03", "Basilic des Cavernes", Rarity.EPIQUE, 5, 8, 3, CardSymbol.SERPENT, "Son regard pétrifie l'audacieux."),
        CardTemplate("e04", "Spectre du Néant", Rarity.EPIQUE, 5, 6, 5, CardSymbol.SPECTRE, "Il se nourrit des souvenirs perdus."),
        CardTemplate("e05", "Griffon Royal", Rarity.EPIQUE, 6, 7, 6, CardSymbol.GRIFFON, "Monture des anciens rois."),
        CardTemplate("e06", "Kraken Tempête", Rarity.EPIQUE, 7, 8, 7, CardSymbol.KRAKEN, "Ses tentacules déchaînent les vagues."),
        CardTemplate("e07", "Archidémon", Rarity.EPIQUE, 6, 8, 5, CardSymbol.DEMON, "Commande les légions infernales."),
        CardTemplate("e08", "Séraphin Vengeur", Rarity.EPIQUE, 6, 6, 7, CardSymbol.ANGE, "La justice divine incarnée."),

        // ---- LÉGENDAIRE ----
        CardTemplate("l01", "Fenrir, l'Ombre Dévorante", Rarity.LEGENDAIRE, 8, 10, 8, CardSymbol.LOUP, "Prophétisé pour engloutir le soleil."),
        CardTemplate("l02", "Atlas, le Porteur de Mondes", Rarity.LEGENDAIRE, 9, 8, 12, CardSymbol.GOLEM, "Il soutient le ciel sur ses épaules de pierre."),
        CardTemplate("l03", "Jörmungandr Ancestral", Rarity.LEGENDAIRE, 9, 11, 7, CardSymbol.SERPENT, "Le serpent qui enserre le monde."),
        CardTemplate("l04", "Léviathan des Abysses", Rarity.LEGENDAIRE, 10, 11, 10, CardSymbol.KRAKEN, "Une seule vague suffit à effacer une flotte."),
        CardTemplate("l05", "Baalzur, Seigneur des Flammes Noires", Rarity.LEGENDAIRE, 9, 11, 8, CardSymbol.DEMON, "Son trône est fait de crânes calcinés."),
        CardTemplate("l06", "Ignis Rex, Roi Dragon", Rarity.LEGENDAIRE, 10, 12, 9, CardSymbol.DRAGON, "Son règne a duré mille ans de cendres."),

        // ---- MYTHIQUE ----
        CardTemplate("m01", "Aeon, l'Œil du Temps", Rarity.MYTHIQUE, 12, 13, 12, CardSymbol.SPECTRE, "Il a vu naître et mourir des univers entiers."),
        CardTemplate("m02", "Solacielle, Genèse Ailée", Rarity.MYTHIQUE, 12, 12, 13, CardSymbol.ANGE, "Née du premier rayon de lumière."),
        CardTemplate("m03", "Nyxdrath, le Dévoreur d'Étoiles", Rarity.MYTHIQUE, 13, 14, 12, CardSymbol.DRAGON, "Chaque nuit sans étoiles est son œuvre.")
    )

    private val loreByRarity = mapOf(
        Rarity.COMMUN to listOf(
            "Une créature du commun, mais jamais à sous-estimer.",
            "On en croise dans presque chaque contrée du royaume.",
            "Simple mais fiable au combat.",
            "Son espèce peuple les terres depuis des générations."
        ),
        Rarity.RARE to listOf(
            "Peu de dresseurs peuvent se vanter d'en avoir capturé une.",
            "Sa force dépasse largement celle de ses semblables communs.",
            "On raconte qu'elle choisit elle-même son maître.",
            "Un spécimen recherché par tous les collectionneurs."
        ),
        Rarity.EPIQUE to listOf(
            "Son pouvoir a changé le cours de plusieurs batailles.",
            "Peu osent l'affronter en combat singulier.",
            "Elle porte les cicatrices d'innombrables guerres.",
            "Sa seule présence fait fuir les créatures plus faibles."
        ),
        Rarity.LEGENDAIRE to listOf(
            "Son nom est gravé dans les annales du royaume.",
            "Une seule apparition suffit à changer le destin d'une bataille.",
            "Les anciens textes parlent d'elle comme d'un fléau ou d'un sauveur.",
            "Peu ont survécu pour raconter leur rencontre avec elle."
        )
    )

    private val symbolLabel = mapOf(
        CardSymbol.DRAGON to "Dragon",
        CardSymbol.PHOENIX to "Phénix",
        CardSymbol.GOLEM to "Golem",
        CardSymbol.SPECTRE to "Spectre",
        CardSymbol.KRAKEN to "Kraken",
        CardSymbol.LOUP to "Loup",
        CardSymbol.SERPENT to "Serpent",
        CardSymbol.TITAN to "Titan",
        CardSymbol.DEMON to "Démon",
        CardSymbol.ANGE to "Ange",
        CardSymbol.HYDRE to "Hydre",
        CardSymbol.GRIFFON to "Griffon"
    )

    private val adjectivesByRarity = mapOf(
        Rarity.COMMUN to listOf(
            "des Prairies", "du Vieux Chemin", "de la Clairière", "des Terres Grises",
            "du Marécage", "des Roseaux", "de la Vallée Calme", "des Pierres Grises",
            "du Bois Mort", "des Terres Arides"
        ),
        Rarity.RARE to listOf(
            "des Vents Glacés", "de l'Orage Pourpre", "des Récifs Noirs", "de la Lame Brisée",
            "des Cendres Vives", "du Crépuscule", "des Flammes Bleues", "de la Marée Haute",
            "des Pics Gelés", "du Sable Mouvant"
        ),
        Rarity.EPIQUE to listOf(
            "du Chaos Ancien", "des Larmes de Sang", "de l'Éclipse Totale", "des Ombres Rampantes",
            "du Trône Brisé", "des Cieux Déchirés", "de la Faille Béante", "des Âmes Errantes",
            "du Volcan Endormi", "des Étoiles Mortes"
        ),
        Rarity.LEGENDAIRE to listOf(
            "le Ravageur des Âges", "l'Immuable", "le Briseur de Serments",
            "le Cœur des Tempêtes", "le Dernier Rempart", "l'Oublié des Dieux"
        )
    )

    private val statVariants = mapOf(
        Rarity.COMMUN to listOf(Triple(1, 1, 2), Triple(1, 2, 1), Triple(2, 2, 3), Triple(2, 3, 2), Triple(3, 2, 4), Triple(1, 3, 1)),
        Rarity.RARE to listOf(Triple(3, 4, 3), Triple(3, 3, 5), Triple(4, 5, 4), Triple(4, 4, 6), Triple(5, 5, 3), Triple(5, 6, 2)),
        Rarity.EPIQUE to listOf(Triple(5, 6, 5), Triple(5, 7, 4), Triple(6, 7, 6), Triple(6, 8, 5), Triple(7, 8, 7), Triple(7, 7, 9)),
        Rarity.LEGENDAIRE to listOf(Triple(8, 9, 9), Triple(8, 10, 8), Triple(9, 10, 10), Triple(9, 11, 9), Triple(10, 11, 11), Triple(10, 12, 10))
    )

    /** Nombre de cartes à générer en plus des cartes écrites à la main, pour atteindre plus de 200 cartes au total. */
    private val extraCounts = mapOf(
        Rarity.COMMUN to 88,
        Rarity.RARE to 45,
        Rarity.EPIQUE to 22,
        Rarity.LEGENDAIRE to 6
    )

    private fun generateExtraCards(): List<CardTemplate> {
        val symbols = CardSymbol.entries
        val result = mutableListOf<CardTemplate>()
        for ((rarity, count) in extraCounts) {
            val adjectives = adjectivesByRarity.getValue(rarity)
            val variants = statVariants.getValue(rarity)
            val lore = loreByRarity.getValue(rarity)
            var generated = 0
            var symbolIndex = 0
            var adjectiveIndex = 0
            while (generated < count) {
                val symbol = symbols[symbolIndex % symbols.size]
                val adjective = adjectives[adjectiveIndex % adjectives.size]
                val (cost, attack, defense) = variants[generated % variants.size]
                val id = "g${rarity.name.take(1).lowercase()}${generated + 1}"
                result.add(
                    CardTemplate(
                        id = id,
                        name = "${symbolLabel.getValue(symbol)} $adjective",
                        rarity = rarity,
                        cost = cost,
                        attack = attack,
                        defense = defense,
                        symbol = symbol,
                        lore = lore[generated % lore.size]
                    )
                )
                generated += 1
                symbolIndex += 1
                if (symbolIndex % symbols.size == 0) adjectiveIndex += 1
            }
        }
        return result
    }

    val allCards: List<CardTemplate> = curatedCards + generateExtraCards()

    fun byId(id: String): CardTemplate? = allCards.find { it.id == id }

    fun cardsOfRarity(rarity: Rarity): List<CardTemplate> = allCards.filter { it.rarity == rarity }

    /** Tirage pondéré selon les taux de drop, avec une pincée de chance boostée pour les boosters premium. */
    fun randomCard(luckBoost: Double = 0.0): CardTemplate {
        val roll = Math.random()
        val boosted = listOf(
            Rarity.COMMUN to (Rarity.COMMUN.dropRate - luckBoost * 0.5).coerceAtLeast(0.05),
            Rarity.RARE to Rarity.RARE.dropRate,
            Rarity.EPIQUE to (Rarity.EPIQUE.dropRate + luckBoost * 0.25),
            Rarity.LEGENDAIRE to (Rarity.LEGENDAIRE.dropRate + luckBoost * 0.2),
            Rarity.MYTHIQUE to (Rarity.MYTHIQUE.dropRate + luckBoost * 0.05)
        )
        var cumulative = 0.0
        val total = boosted.sumOf { it.second }
        for ((rarity, rate) in boosted) {
            cumulative += rate / total
            if (roll <= cumulative) {
                return cardsOfRarity(rarity).random()
            }
        }
        return cardsOfRarity(Rarity.COMMUN).random()
    }

    fun starterDeckIds(): List<String> = listOf("c01", "c02", "c03", "c04", "c05", "c07", "c09", "c10")
}
