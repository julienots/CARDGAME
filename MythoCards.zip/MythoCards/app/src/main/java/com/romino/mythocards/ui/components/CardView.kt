package com.romino.mythocards.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.lerp
import com.romino.mythocards.data.CardDatabase
import com.romino.mythocards.model.CardTemplate
import com.romino.mythocards.model.Rarity

@Composable
fun GameCardView(
    template: CardTemplate,
    modifier: Modifier = Modifier,
    count: Int? = null,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .border(rarityBorder(template.rarity), RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = template.rarity.secondaryColor)
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatBadge(text = "${template.cost}", color = Color(0xFF48CAE4))
                if (count != null) {
                    Text("x$count", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(10.dp))
            ) {
                CardArt(template.symbol, template.rarity, template.id.hashCode(), Modifier.fillMaxSize())
            }
            Text(
                text = template.name,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                modifier = Modifier.padding(top = 4.dp)
            )
            Text(
                text = template.rarity.label,
                color = template.rarity.glow,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
            CardDatabase.abilityText(template.rarity)?.let { ability ->
                Text(
                    text = ability,
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 8.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    lineHeight = 9.sp
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatBadge(text = "⚔ ${template.attack}", color = Color(0xFFE63946))
                StatBadge(text = "🛡 ${template.defense}", color = Color(0xFF52B788))
            }
        }
    }
}

@Composable
private fun StatBadge(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

/** Couleurs du contour animé des raretés ultra. */
private fun ultraPalette(rarity: Rarity): List<Color> = when (rarity) {
    Rarity.DIVIN -> listOf(Color(0xFFFFFDE7), Color(0xFFFFD54F), Color(0xFFFFFFFF), Color(0xFFFFB300))
    Rarity.COSMIQUE -> listOf(Color(0xFF3A86FF), Color(0xFF8338EC), Color(0xFFFF006E), Color(0xFF00F5D4))
    Rarity.PRIMORDIAL -> listOf(Color(0xFFFF5400), Color(0xFFFFBD00), Color(0xFF9D0208), Color(0xFFFF8500))
    Rarity.SYMBIOT -> listOf(Color(0xFF00F5A0), Color(0xFF000000), Color(0xFF7CFFCB), Color(0xFF111111), Color(0xFFB4FF00))
    else -> listOf(rarity.glow, rarity.primaryColor)
}

@Composable
private fun rarityBorder(rarity: Rarity): BorderStroke {
    if (!rarity.isUltra) return BorderStroke(2.dp, rarity.glow)
    val transition = rememberInfiniteTransition(label = "ultraBorder")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(if (rarity == Rarity.SYMBIOT) 1200 else 2400, easing = LinearEasing)),
        label = "phase"
    )
    val palette = ultraPalette(rarity)
    val n = palette.size
    val pos = phase * n
    val base = pos.toInt()
    val frac = pos - base
    val colors = List(n + 1) { i ->
        lerp(palette[(i + base) % n], palette[(i + base + 1) % n], frac)
    }
    return BorderStroke(if (rarity == Rarity.SYMBIOT) 4.dp else 3.dp, Brush.sweepGradient(colors))
}
