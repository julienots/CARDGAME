package com.romino.mythocards.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.romino.mythocards.data.CardDatabase
import com.romino.mythocards.data.GameRepository
import com.romino.mythocards.model.Rarity

@Composable
fun CollectionScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0D1B2A), Color(0xFF1B263B))))
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("Ma Collection", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "${GameRepository.collection.size} / ${CardDatabase.allCards.size} cartes découvertes",
                color = Color(0xFF8D99AE),
                fontSize = 13.sp
            )
            Spacer(Modifier.height(12.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (rarity in Rarity.entries) {
                    val cardsOfRarity = CardDatabase.cardsOfRarity(rarity)
                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                        val ownedOfRarity = cardsOfRarity.count { (GameRepository.collection[it.id] ?: 0) > 0 }
                        Text(
                            "${rarity.label}  ($ownedOfRarity / ${cardsOfRarity.size})",
                            color = rarity.glow,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )
                    }
                    items(cardsOfRarity) { template ->
                        val owned = GameRepository.collection[template.id] ?: 0
                        if (owned > 0) {
                            com.romino.mythocards.ui.components.GameCardView(
                                template = template,
                                count = owned,
                                modifier = Modifier.height(230.dp)
                            )
                        } else {
                            LockedCardSlot()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LockedCardSlot() {
    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .height(230.dp)
            .fillMaxWidth()
            .background(Color(0xFF1B263B), androidx.compose.foundation.shape.RoundedCornerShape(14.dp)),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        Text("?", color = Color(0xFF415A77), fontSize = 36.sp, fontWeight = FontWeight.Bold)
    }
}
