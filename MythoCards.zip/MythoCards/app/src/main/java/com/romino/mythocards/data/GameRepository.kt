package com.romino.mythocards.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue

/**
 * Source de vérité unique pour la progression du joueur : or, collection de cartes,
 * inventaire de boosters non ouverts. Persisté simplement via SharedPreferences.
 */
object GameRepository {

    private lateinit var prefs: SharedPreferences
    private var initialized = false

    var gold by mutableIntStateOf(500)
    val collection = mutableStateMapOf<String, Int>() // cardId -> quantité possédée

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        prefs = context.applicationContext.getSharedPreferences("mythocards_save", Context.MODE_PRIVATE)
        gold = prefs.getInt("gold", 500)
        val saved = prefs.getString("collection", null)
        if (saved.isNullOrBlank()) {
            // Nouveau joueur : deck de départ offert
            CardDatabase.starterDeckIds().forEach { collection[it] = 1 }
            persist()
        } else {
            saved.split(";").filter { it.isNotBlank() }.forEach { entry ->
                val (id, count) = entry.split(":")
                collection[id] = count.toInt()
            }
        }
    }

    fun addCard(cardId: String) {
        collection[cardId] = (collection[cardId] ?: 0) + 1
        persist()
    }

    fun spendGold(amount: Int): Boolean {
        if (gold < amount) return false
        gold -= amount
        persist()
        return true
    }

    fun earnGold(amount: Int) {
        gold += amount
        persist()
    }

    fun ownedCardIds(): List<String> = collection.filter { it.value > 0 }.keys.toList()

    private fun persist() {
        val serialized = collection.entries.joinToString(";") { "${it.key}:${it.value}" }
        prefs.edit()
            .putInt("gold", gold)
            .putString("collection", serialized)
            .apply()
    }
}
