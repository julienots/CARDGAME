package com.romino.mythocards.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Shop
import androidx.compose.material.icons.filled.SportsMma
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.romino.mythocards.ui.screens.BattleScreen
import com.romino.mythocards.ui.screens.CollectionScreen
import com.romino.mythocards.ui.screens.HomeScreen
import com.romino.mythocards.ui.screens.ShopScreen

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val tabs = listOf(
    Tab("accueil", "Accueil", Icons.Filled.Home),
    Tab("boutique", "Boutique", Icons.Filled.Shop),
    Tab("collection", "Cartes", Icons.Filled.Style),
    Tab("combat", "Combat", Icons.Filled.SportsMma)
)

@Composable
fun MythoCardsApp() {
    val navController = rememberNavController()

    Scaffold(
        containerColor = Color(0xFF0D1B2A),
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination
            NavigationBar(containerColor = Color(0xFF1B263B)) {
                tabs.forEach { tab ->
                    val selected = currentRoute?.hierarchy?.any { it.route == tab.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFFFD873),
                            selectedTextColor = Color(0xFFFFD873),
                            unselectedIconColor = Color(0xFF8D99AE),
                            unselectedTextColor = Color(0xFF8D99AE),
                            indicatorColor = Color(0xFF2B2D42)
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "accueil",
            modifier = Modifier.padding(padding)
        ) {
            composable("accueil") { HomeScreen(onNavigate = { navController.navigate(it) }) }
            composable("boutique") { ShopScreen() }
            composable("collection") { CollectionScreen() }
            composable("combat") { BattleScreen(onExit = { navController.navigate("accueil") { launchSingleTop = true } }) }
        }
    }
}
