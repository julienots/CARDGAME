package com.romino.mythocards.model

import androidx.compose.ui.graphics.Color

enum class Rarity(
    val label: String,
    val dropRate: Double,
    val primaryColor: Color,
    val secondaryColor: Color,
    val glow: Color,
    /** Rang de puissance (0 = commun). Sert au tri, aux effets visuels et aux boosters. */
    val tier: Int
) {
    COMMUN("Commun", 0.55, Color(0xFF8D99AE), Color(0xFF2B2D42), Color(0xFFB0B8C4), 0),
    RARE("Rare", 0.27, Color(0xFF4CC9F0), Color(0xFF1B263B), Color(0xFF80E5FF), 1),
    EPIQUE("Épique", 0.12, Color(0xFF9D4EDD), Color(0xFF3C096C), Color(0xFFD59CFF), 2),
    LEGENDAIRE("Légendaire", 0.05, Color(0xFFFFB703), Color(0xFF6A040F), Color(0xFFFFD873), 3),
    MYTHIQUE("Mythique", 0.01, Color(0xFFFF006E), Color(0xFF000000), Color(0xFFFF7EB6), 4),
    DIVIN("Divin", 0.004, Color(0xFFFFF3B0), Color(0xFF7A5C00), Color(0xFFFFFDE7), 5),
    COSMIQUE("Cosmique", 0.002, Color(0xFF3A86FF), Color(0xFF03001C), Color(0xFF8EC5FF), 6),
    PRIMORDIAL("Primordial", 0.0008, Color(0xFFFF5400), Color(0xFF1A0000), Color(0xFFFFA36C), 7),
    SYMBIOT("Symbiot", 0.0003, Color(0xFF00F5A0), Color(0xFF020202), Color(0xFF7CFFCB), 8);

    /** Les raretés au-delà de Mythique ont une bordure animée et des pouvoirs spéciaux. */
    val isUltra: Boolean get() = tier >= DIVIN.tier
}

enum class CardSymbol {
    DRAGON, PHOENIX, GOLEM, SPECTRE, KRAKEN, LOUP, SERPENT, TITAN, DEMON, ANGE, HYDRE, GRIFFON,
    // Nouveaux symboles (ajoutés à la fin pour ne pas renommer les anciennes cartes générées)
    SYMBIOTE, CHIMERE, LICHE
}

data class CardTemplate(
    val id: String,
    val name: String,
    val rarity: Rarity,
    val cost: Int,
    val attack: Int,
    val defense: Int,
    val symbol: CardSymbol,
    val lore: String
)
