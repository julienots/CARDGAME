package com.romino.mythocards.model

import androidx.compose.ui.graphics.Color

enum class Rarity(
    val label: String,
    val dropRate: Double,
    val primaryColor: Color,
    val secondaryColor: Color,
    val glow: Color
) {
    COMMUN("Commun", 0.55, Color(0xFF8D99AE), Color(0xFF2B2D42), Color(0xFFB0B8C4)),
    RARE("Rare", 0.27, Color(0xFF4CC9F0), Color(0xFF1B263B), Color(0xFF80E5FF)),
    EPIQUE("Épique", 0.12, Color(0xFF9D4EDD), Color(0xFF3C096C), Color(0xFFD59CFF)),
    LEGENDAIRE("Légendaire", 0.05, Color(0xFFFFB703), Color(0xFF6A040F), Color(0xFFFFD873)),
    MYTHIQUE("Mythique", 0.01, Color(0xFFFF006E), Color(0xFF000000), Color(0xFFFF7EB6))
}

enum class CardSymbol {
    DRAGON, PHOENIX, GOLEM, SPECTRE, KRAKEN, LOUP, SERPENT, TITAN, DEMON, ANGE, HYDRE, GRIFFON
}

data class CardTemplate(
    val id: String,
    val name: String,
    val rarity: Rarity,
    val cost: Int,
    val attack: Int,
    val defense: Int,
    val symbol: CardSymbol,
    val lore: String
)
