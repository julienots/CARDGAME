package com.romino.mythocards.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.romino.mythocards.model.CardTemplate
import com.romino.mythocards.ui.components.CardArt
import com.romino.mythocards.ui.components.GameCardView

@Composable
fun BoosterOpeningOverlay(cards: List<CardTemplate>, onFinished: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }

    val rotation by animateFloatAsState(
        targetValue = if (flipped) 180f else 0f,
        animationSpec = tween(500),
        label = "flip"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000814)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "Carte ${index + 1} / ${cards.size}",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .size(220.dp, 300.dp)
                    .graphicsLayer {
                        rotationY = rotation
                        cameraDistance = 12f * density
                    }
                    .clickable {
                        if (!flipped) flipped = true
                    },
                contentAlignment = Alignment.Center
            ) {
                if (rotation <= 90f) {
                    // Dos de carte
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF3A0CA3), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✦ MythoCards ✦", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Box(modifier = Modifier.graphicsLayer { rotationY = 180f }) {
                        GameCardView(template = cards[index], modifier = Modifier.size(220.dp, 300.dp))
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            if (!flipped) {
                Text("Touchez la carte pour la révéler", color = Color(0xFF8D99AE), fontSize = 13.sp)
            } else {
                Button(
                    onClick = {
                        if (index < cards.size - 1) {
                            index += 1
                            flipped = false
                        } else {
                            onFinished()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB703))
                ) {
                    Text(
                        if (index < cards.size - 1) "Carte suivante" else "Terminer",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
