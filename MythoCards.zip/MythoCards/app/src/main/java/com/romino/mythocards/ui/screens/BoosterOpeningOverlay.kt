package com.romino.mythocards.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.romino.mythocards.model.CardTemplate
import com.romino.mythocards.model.Rarity
import com.romino.mythocards.ui.components.GameCardView

@Composable
fun BoosterOpeningOverlay(title: String = "Booster", cards: List<CardTemplate>, onFinished: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    var showSummary by remember { mutableStateOf(false) }

    val rotation by animateFloatAsState(
        targetValue = if (flipped) 180f else 0f,
        animationSpec = tween(500),
        label = "flip"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE000814)),
        contentAlignment = Alignment.Center
    ) {
        if (showSummary) {
            SummaryView(title, cards, onFinished)
        } else {
        val card = cards[index]
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color(0xFFFFD873), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Carte ${index + 1} / ${cards.size}",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .size(220.dp, 310.dp)
                    .graphicsLayer {
                        rotationY = rotation
                        cameraDistance = 12f * density
                    }
                    .clickable {
                        if (!flipped) flipped = true
                    },
                contentAlignment = Alignment.Center
            ) {
                if (rotation <= 90f) {
                    // Dos de carte : il brille déjà si une carte ultra se cache derrière
                    val backBrush = if (card.rarity.tier >= Rarity.MYTHIQUE.tier)
                        Brush.verticalGradient(listOf(card.rarity.primaryColor, Color(0xFF3A0CA3), card.rarity.glow))
                    else Brush.verticalGradient(listOf(Color(0xFF3A0CA3), Color(0xFF3A0CA3)))
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(backBrush, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✦ MythoCards ✦", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Box(modifier = Modifier.graphicsLayer { rotationY = 180f }) {
                        GameCardView(template = card, modifier = Modifier.size(220.dp, 310.dp))
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            if (flipped && card.rarity.isUltra) {
                Text(
                    when (card.rarity) {
                        Rarity.SYMBIOT -> "🧬 SYMBIOT !!! 🧬"
                        Rarity.PRIMORDIAL -> "🌋 PRIMORDIAL !!"
                        Rarity.COSMIQUE -> "🌌 COSMIQUE !"
                        else -> "✨ DIVIN !"
                    },
                    color = card.rarity.glow,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(Modifier.height(8.dp))
            }

            if (!flipped) {
                Text("Touchez la carte pour la révéler", color = Color(0xFF8D99AE), fontSize = 13.sp)
            } else {
                Button(
                    onClick = {
                        if (index < cards.size - 1) {
                            index += 1
                            flipped = false
                        } else {
                            showSummary = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB703))
                ) {
                    Text(
                        if (index < cards.size - 1) "Carte suivante" else "Voir le résumé",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            if (cards.size > 1 && index < cards.size - 1) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showSummary = true }) {
                    Text("Tout révéler", color = Color.White)
                }
            }
        }
        }
    }
}

@Composable
private fun SummaryView(title: String, cards: List<CardTemplate>, onFinished: () -> Unit) {
    val sorted = remember(cards) { cards.sortedByDescending { it.rarity.tier } }
    Column(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Color(0xFFFFD873), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        val best = sorted.first().rarity
        Text(
            "${cards.size} cartes • meilleure : ${best.label}",
            color = best.glow,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(sorted) { card ->
                GameCardView(template = card, modifier = Modifier.height(200.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onFinished,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB703)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Ajouter à ma collection", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}
