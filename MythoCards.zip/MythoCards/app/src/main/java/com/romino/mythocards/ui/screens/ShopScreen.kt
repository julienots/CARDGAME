package com.romino.mythocards.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.romino.mythocards.data.CardDatabase
import com.romino.mythocards.data.GameRepository
import com.romino.mythocards.model.CardTemplate

@Composable
fun ShopScreen() {
    var revealedCards by remember { mutableStateOf<List<CardTemplate>?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0D1B2A), Color(0xFF1B263B))))
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            Text("Boutique", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("💰 ${GameRepository.gold} pièces d'or", color = Color(0xFFFFD873), fontSize = 16.sp)
            Spacer(Modifier.height(20.dp))

            BoosterOffer(
                title = "Booster Standard",
                description = "5 cartes • chances normales",
                price = 100,
                accent = Color(0xFF4CC9F0)
            ) {
                if (GameRepository.spendGold(100)) {
                    revealedCards = List(5) { CardDatabase.randomCard() }
                } else errorMessage = "Pas assez d'or !"
            }

            Spacer(Modifier.height(16.dp))

            BoosterOffer(
                title = "Booster Premium",
                description = "5 cartes • chances de rareté augmentées",
                price = 300,
                accent = Color(0xFF9D4EDD)
            ) {
                if (GameRepository.spendGold(300)) {
                    revealedCards = List(5) { CardDatabase.randomCard(luckBoost = 0.3) }
                } else errorMessage = "Pas assez d'or !"
            }

            Spacer(Modifier.height(16.dp))

            BoosterOffer(
                title = "Booster Mythique",
                description = "5 cartes • rareté fortement augmentée",
                price = 800,
                accent = Color(0xFFFF006E)
            ) {
                if (GameRepository.spendGold(800)) {
                    revealedCards = List(5) { CardDatabase.randomCard(luckBoost = 0.6) }
                } else errorMessage = "Pas assez d'or !"
            }

            errorMessage?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Color(0xFFE63946), fontWeight = FontWeight.Bold)
            }
        }

        revealedCards?.let { cards ->
            BoosterOpeningOverlay(cards = cards) {
                cards.forEach { GameRepository.addCard(it.id) }
                revealedCards = null
                errorMessage = null
            }
        }
    }
}

@Composable
private fun BoosterOffer(title: String, description: String, price: Int, accent: Color, onBuy: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2D42)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(description, color = Color(0xFF8D99AE), fontSize = 12.sp)
            }
            Button(onClick = onBuy, colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                Text("$price 💰", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
