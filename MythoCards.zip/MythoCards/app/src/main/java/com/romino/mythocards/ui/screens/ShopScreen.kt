package com.romino.mythocards.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.romino.mythocards.data.CardDatabase
import com.romino.mythocards.data.GameRepository
import com.romino.mythocards.model.CardTemplate
import com.romino.mythocards.model.Rarity

/** Un type de booster : nombre de cartes, chance, et rareté garantie sur la dernière carte. */
data class BoosterType(
    val title: String,
    val description: String,
    val price: Int,
    val accent: Color,
    val cardCount: Int,
    val luckBoost: Double,
    val guaranteed: Rarity? = null
) {
    fun open(): List<CardTemplate> = List(cardCount) { i ->
        if (i == cardCount - 1 && guaranteed != null) CardDatabase.randomCard(luckBoost, minRarity = guaranteed)
        else CardDatabase.randomCard(luckBoost)
    }
}

/** Une display = une boîte contenant plusieurs boosters (moins chère que les boosters à l'unité). */
data class DisplayType(
    val title: String,
    val description: String,
    val price: Int,
    val accent: Color,
    val booster: BoosterType,
    val boosterCount: Int,
    val bonusRarity: Rarity? = null
) {
    fun open(): List<CardTemplate> {
        val cards = List(boosterCount) { booster.open() }.flatten().toMutableList()
        bonusRarity?.let { cards.add(CardDatabase.randomCard(1.5, minRarity = it)) }
        return cards
    }
}

object Shop {
    val standard = BoosterType("Booster Standard", "5 cartes • chances normales", 100, Color(0xFF4CC9F0), 5, 0.0)
    val premium = BoosterType("Booster Premium", "5 cartes • chances de rareté augmentées", 300, Color(0xFF9D4EDD), 5, 0.3)
    val mythique = BoosterType("Booster Mythique", "5 cartes • rareté fortement augmentée", 800, Color(0xFFFF006E), 5, 0.6)
    val divin = BoosterType("Booster Divin", "5 cartes • 1 Légendaire ou mieux garantie", 1200, Color(0xFFFFF3B0), 5, 0.8, Rarity.LEGENDAIRE)
    val cosmique = BoosterType("Booster Cosmique", "6 cartes • 1 Mythique ou mieux garantie", 2000, Color(0xFF3A86FF), 6, 1.0, Rarity.MYTHIQUE)
    val primordial = BoosterType("Booster Primordial", "7 cartes • 1 Divine ou mieux garantie", 3500, Color(0xFFFF5400), 7, 1.2, Rarity.DIVIN)
    val symbiot = BoosterType("Booster Symbiot", "5 cartes • 1 carte SYMBIOT garantie !", 6000, Color(0xFF00F5A0), 5, 1.5, Rarity.SYMBIOT)

    val boosters = listOf(standard, premium, mythique, divin, cosmique, primordial, symbiot)

    val displays = listOf(
        DisplayType("Display Standard", "10 Boosters Standard (50 cartes)", 850, Color(0xFF4CC9F0), standard, 10),
        DisplayType("Display Premium", "10 Boosters Premium (50 cartes)", 2500, Color(0xFF9D4EDD), premium, 10),
        DisplayType("Display Mythique", "10 Boosters Mythiques (50 cartes)", 6500, Color(0xFFFF006E), mythique, 10),
        DisplayType("Display Céleste", "8 Boosters Divins + 1 Cosmique bonus", 8500, Color(0xFFFFD54F), divin, 8, Rarity.COSMIQUE),
        DisplayType("Display Éveil Symbiotique", "6 Boosters Primordiaux + 1 SYMBIOT bonus", 18000, Color(0xFF00F5A0), primordial, 6, Rarity.SYMBIOT)
    )
}

@Composable
fun ShopScreen() {
    var revealed by remember { mutableStateOf<Pair<String, List<CardTemplate>>?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0D1B2A), Color(0xFF1B263B))))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Text("Boutique", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("💰 ${GameRepository.gold} pièces d'or", color = Color(0xFFFFD873), fontSize = 16.sp)

            errorMessage?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = Color(0xFFE63946), fontWeight = FontWeight.Bold)
            }

            SectionTitle("🎁 Boosters")
            Shop.boosters.forEach { booster ->
                BoosterOffer(booster.title, booster.description, booster.price, booster.accent, booster.guaranteed?.isUltra == true) {
                    if (GameRepository.spendGold(booster.price)) {
                        revealed = booster.title to booster.open()
                        errorMessage = null
                    } else errorMessage = "Pas assez d'or pour ${booster.title} !"
                }
                Spacer(Modifier.height(12.dp))
            }

            SectionTitle("📦 Displays")
            Text(
                "Une boîte entière de boosters, moins chère qu'à l'unité.",
                color = Color(0xFF8D99AE),
                fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            Shop.displays.forEach { display ->
                BoosterOffer(display.title, display.description, display.price, display.accent, display.bonusRarity?.isUltra == true) {
                    if (GameRepository.spendGold(display.price)) {
                        revealed = display.title to display.open()
                        errorMessage = null
                    } else errorMessage = "Pas assez d'or pour ${display.title} !"
                }
                Spacer(Modifier.height(12.dp))
            }

            SectionTitle("📊 Taux de rareté")
            Rarity.entries.forEach { r ->
                Text(
                    "${r.label} : ${formatRate(r.dropRate)} • ${CardDatabase.cardsOfRarity(r).size} cartes",
                    color = r.glow,
                    fontSize = 12.sp
                )
            }
            Spacer(Modifier.height(24.dp))
        }

        revealed?.let { (title, cards) ->
            BoosterOpeningOverlay(title = title, cards = cards) {
                cards.forEach { GameRepository.addCard(it.id) }
                revealed = null
                errorMessage = null
            }
        }
    }
}

private fun formatRate(rate: Double): String {
    val pct = rate * 100
    return if (pct >= 1) "${pct.toInt()} %" else "${"%.2f".format(pct)} %"
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(20.dp))
    Text(text, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun BoosterOffer(title: String, description: String, price: Int, accent: Color, highlight: Boolean, onBuy: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2D42)),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (highlight) Modifier.border(2.dp, accent, RoundedCornerShape(16.dp)) else Modifier)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = if (highlight) accent else Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(description, color = Color(0xFF8D99AE), fontSize = 12.sp)
            }
            Button(onClick = onBuy, colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                Text("$price 💰", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
