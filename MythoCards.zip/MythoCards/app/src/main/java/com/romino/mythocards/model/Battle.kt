package com.romino.mythocards.model

data class BoardUnit(
    val template: CardTemplate,
    var currentHealth: Int,
    var hasAttacked: Boolean = false
)

enum class Turn { JOUEUR, ENNEMI }
